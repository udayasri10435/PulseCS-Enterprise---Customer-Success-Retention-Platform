import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import { ExpansionSignal } from '../types';
import {
  Zap,
  CheckCircle2,
  XCircle,
  Clock,
  ArrowRight,
  TrendingUp,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';

interface ExpansionRadarProps {
  onOpenAccount: (accountId: string) => void;
}

export const ExpansionRadar: React.FC<ExpansionRadarProps> = ({ onOpenAccount }) => {
  const {
    expansionSignals,
    convertExpansionToPlaybook,
    updateExpansionSignalStatus,
  } = useCS();

  const [filter, setFilter] = useState<'all' | 'New' | 'In Progress' | 'Converted'>('all');

  const activeSignals = expansionSignals.filter((s) => s.status !== 'Dismissed');
  const totalExpansionPotential = activeSignals.reduce((acc, s) => acc + s.potentialArr, 0);

  const filteredSignals = expansionSignals.filter((s) => {
    if (filter !== 'all' && s.status !== filter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Title & Context */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Expansion Signal Radar
          </h1>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            Algorithmic Account Upsell & Cross-Sell Telemetry · +${(totalExpansionPotential / 1_000).toFixed(0)}K Identified ARR
          </div>
        </div>

        {/* Filter buttons */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
          {[
            { id: 'all', label: `All (${expansionSignals.length})` },
            { id: 'New', label: `New (${expansionSignals.filter((s) => s.status === 'New').length})` },
            { id: 'In Progress', label: 'In Progress' },
            { id: 'Converted', label: 'Converted' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                filter === tab.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Identified Expansion ARR</div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-1">
            +${(totalExpansionPotential / 1_000).toFixed(0)}K
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Across {activeSignals.length} active opportunities
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">New Unactioned Triggers</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            {expansionSignals.filter((s) => s.status === 'New').length}
          </div>
          <div className="text-xs text-cyan-400 mt-1 font-mono">
            Detected via product usage events
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Avg Conversion Velocity</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">
            18 Days
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Signal detection to closed amendment
          </div>
        </div>
      </div>

      {/* Signals Cards Grid */}
      <div className="space-y-4">
        {filteredSignals.map((signal) => {
          const isImmediate = signal.urgency === 'Immediate';
          const isHigh = signal.urgency === 'High';

          return (
            <div
              key={signal.id}
              className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 space-y-3 transition-colors hover:border-slate-700"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-cyan-950/80 border border-cyan-800/80 flex items-center justify-center shrink-0">
                    <Zap className="w-4 h-4 text-cyan-400" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-white">{signal.type}</span>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                          isImmediate
                            ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                            : isHigh
                              ? 'bg-amber-950/80 border-amber-800 text-amber-300'
                              : 'bg-slate-800 border-slate-700 text-slate-300'
                        }`}
                      >
                        Urgency: {signal.urgency}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                      <span>Account:</span>
                      <button
                        onClick={() => onOpenAccount(signal.accountId)}
                        className="text-cyan-400 hover:underline font-semibold"
                      >
                        {signal.accountName}
                      </button>
                      <span aria-hidden="true">·</span>
                      <span>Detected: {signal.detectedDate}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right font-mono shrink-0">
                  <div className="text-base font-bold text-emerald-400">
                    +${(signal.potentialArr / 1000).toFixed(0)}k ARR
                  </div>
                  <div className="text-[11px] text-slate-500">Estimated Uplift</div>
                </div>
              </div>

              {/* Detail prose */}
              <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-950/50 p-3 rounded-lg border border-slate-800/60">
                {signal.detail}
              </p>

              {/* Recommended Action & Trigger CTA */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <div className="text-xs text-slate-400">
                  <strong className="text-slate-300">Recommended Action:</strong>{' '}
                  {signal.recommendedAction}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {signal.status === 'New' && (
                    <button
                      onClick={() => convertExpansionToPlaybook(signal.id)}
                      className="px-3 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Convert to Playbook</span>
                    </button>
                  )}

                  {signal.status === 'In Progress' && (
                    <button
                      onClick={() => updateExpansionSignalStatus(signal.id, 'Converted')}
                      className="px-3 py-1.5 text-xs font-semibold text-emerald-300 bg-emerald-950/80 border border-emerald-800 hover:bg-emerald-900 rounded-lg transition-colors flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Mark Converted</span>
                    </button>
                  )}

                  <button
                    onClick={() => onOpenAccount(signal.accountId)}
                    className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    Open 360
                  </button>

                  {signal.status !== 'Dismissed' && (
                    <button
                      onClick={() => updateExpansionSignalStatus(signal.id, 'Dismissed')}
                      className="p-1.5 text-slate-500 hover:text-slate-300"
                      title="Dismiss Signal"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
