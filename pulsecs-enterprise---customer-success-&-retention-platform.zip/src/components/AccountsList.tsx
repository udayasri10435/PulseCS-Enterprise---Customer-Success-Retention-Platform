import React, { useState, useMemo } from 'react';
import { useCS } from '../context/CSContext';
import { Account } from '../types';
import {
  Search,
  ArrowUpDown,
  Filter,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Sparkles,
  Zap,
} from 'lucide-react';

interface AccountsListProps {
  onOpenAccount: (accountId: string) => void;
  onOpenAddAccount: () => void;
}

type SortField = 'name' | 'arr' | 'compositeHealth' | 'daysToRenewal' | 'utilization';
type SortDirection = 'asc' | 'desc';

export const AccountsList: React.FC<AccountsListProps> = ({
  onOpenAccount,
  onOpenAddAccount,
}) => {
  const {
    accounts,
    searchQuery,
    setSearchQuery,
    healthFilter,
    setHealthFilter,
    csmFilter,
    setCsmFilter,
    horizonFilter,
    setHorizonFilter,
  } = useCS();

  const [sortField, setSortField] = useState<SortField>('compositeHealth');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc'); // default lowest health first to surface churn risks

  // Extract unique CSMs
  const uniqueCsms = useMemo(() => {
    return Array.from(new Set(accounts.map((a) => a.csmName)));
  }, [accounts]);

  // Handle Sort Toggle
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      // For ARR or Health, default to desc or asc intuitively
      setSortDirection(field === 'arr' ? 'desc' : 'asc');
    }
  };

  // Filtered & Sorted Accounts
  const filteredAccounts = useMemo(() => {
    return accounts
      .filter((acc) => {
        // Search text
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = acc.name.toLowerCase().includes(q);
          const matchIndustry = acc.industry.toLowerCase().includes(q);
          const matchCsm = acc.csmName.toLowerCase().includes(q);
          if (!matchName && !matchIndustry && !matchCsm) return false;
        }

        // Health Filter
        if (healthFilter === 'champion' && acc.compositeHealth < 85) return false;
        if (healthFilter === 'healthy' && (acc.compositeHealth < 70 || acc.compositeHealth >= 85)) return false;
        if (healthFilter === 'at_risk' && (acc.compositeHealth < 50 || acc.compositeHealth >= 70)) return false;
        if (healthFilter === 'critical' && acc.compositeHealth >= 50) return false;

        // CSM Filter
        if (csmFilter !== 'all' && acc.csmName !== csmFilter) return false;

        // Renewal Horizon Filter
        if (horizonFilter === '30' && acc.daysToRenewal > 30) return false;
        if (horizonFilter === '60' && acc.daysToRenewal > 60) return false;
        if (horizonFilter === '90' && acc.daysToRenewal > 90) return false;

        return true;
      })
      .sort((a, b) => {
        let valA: number | string = 0;
        let valB: number | string = 0;

        switch (sortField) {
          case 'name':
            valA = a.name.toLowerCase();
            valB = b.name.toLowerCase();
            break;
          case 'arr':
            valA = a.arr;
            valB = b.arr;
            break;
          case 'compositeHealth':
            valA = a.compositeHealth;
            valB = b.compositeHealth;
            break;
          case 'daysToRenewal':
            valA = a.daysToRenewal;
            valB = b.daysToRenewal;
            break;
          case 'utilization':
            valA = a.licenses.utilizationPercent;
            valB = b.licenses.utilizationPercent;
            break;
        }

        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortDirection === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        }
        return sortDirection === 'asc' ? (valA as number) - (valB as number) : (valB as number) - (valA as number);
      });
  }, [accounts, searchQuery, healthFilter, csmFilter, horizonFilter, sortField, sortDirection]);

  return (
    <div className="space-y-4">
      {/* Title & Filter Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Customer 360 Portfolio
          </h1>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            Managing {accounts.length} accounts · ${(accounts.reduce((s, a) => s + a.arr, 0) / 1_000_000).toFixed(2)}M Total ARR
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search Input */}
          <div className="relative min-w-[220px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search account, CSM, industry..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
          </div>

          {/* Health Tier Filter Tabs */}
          <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
            <button
              onClick={() => setHealthFilter('all')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                healthFilter === 'all'
                  ? 'bg-slate-800 text-white font-medium shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setHealthFilter('critical')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                healthFilter === 'critical'
                  ? 'bg-rose-950/80 text-rose-300 font-medium border border-rose-800/80'
                  : 'text-slate-400 hover:text-rose-300'
              }`}
            >
              Critical (&lt;50)
            </button>
            <button
              onClick={() => setHealthFilter('at_risk')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                healthFilter === 'at_risk'
                  ? 'bg-amber-950/80 text-amber-300 font-medium border border-amber-800/80'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              At Risk (50–69)
            </button>
            <button
              onClick={() => setHealthFilter('healthy')}
              className={`px-2.5 py-1 rounded-md transition-colors ${
                healthFilter === 'healthy'
                  ? 'bg-cyan-950/80 text-cyan-300 font-medium border border-cyan-800/80'
                  : 'text-slate-400 hover:text-cyan-300'
              }`}
            >
              Healthy (70+)
            </button>
          </div>

          {/* CSM Dropdown */}
          <select
            value={csmFilter}
            onChange={(e) => setCsmFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All CSMs</option>
            {uniqueCsms.map((csm) => (
              <option key={csm} value={csm}>
                {csm}
              </option>
            ))}
          </select>

          {/* Horizon Dropdown */}
          <select
            value={horizonFilter}
            onChange={(e) => setHorizonFilter(e.target.value)}
            className="px-2.5 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-lg text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">Any Renewal Horizon</option>
            <option value="30">Next 30 Days (&lt;30d)</option>
            <option value="60">Next 60 Days (&lt;60d)</option>
            <option value="90">Next 90 Days (&lt;90d)</option>
          </select>
        </div>
      </div>

      {/* High-Density Data Grid / Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-medium font-mono uppercase text-[11px] tracking-wider">
                <th
                  onClick={() => handleSort('name')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Account Name</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('arr')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>ARR (USD)</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('compositeHealth')}
                  className="py-3 px-4 text-center cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-center gap-1.5">
                    <span>Health Score</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-3 px-4">
                  <span>Adoption / Sent / Supp / Comm</span>
                </th>
                <th
                  onClick={() => handleSort('utilization')}
                  className="py-3 px-4 cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center gap-1.5">
                    <span>License Capacity</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </div>
                </th>
                <th
                  onClick={() => handleSort('daysToRenewal')}
                  className="py-3 px-4 text-right cursor-pointer hover:text-slate-200 transition-colors"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Renewal Horizon</span>
                    <ArrowUpDown className="w-3 h-3 text-slate-500" />
                  </div>
                </th>
                <th className="py-3 px-4">
                  <span>Status / CSM</span>
                </th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {filteredAccounts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <p className="text-sm">No customer accounts matched your filter criteria.</p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setHealthFilter('all');
                        setCsmFilter('all');
                        setHorizonFilter('all');
                      }}
                      className="mt-2 text-xs text-cyan-400 hover:underline"
                    >
                      Clear all filters
                    </button>
                  </td>
                </tr>
              ) : (
                filteredAccounts.map((account) => {
                  const isCritical = account.compositeHealth < 50;
                  const isAtRisk = account.compositeHealth >= 50 && account.compositeHealth < 70;
                  const isHealthy = account.compositeHealth >= 70 && account.compositeHealth < 85;
                  const isChampion = account.compositeHealth >= 85;

                  const hasExpansion = account.expansionSignalIds.length > 0;
                  const hasPlaybook = account.activePlaybookIds.length > 0;

                  return (
                    <tr
                      key={account.id}
                      onClick={() => onOpenAccount(account.id)}
                      className="hover:bg-slate-800/40 cursor-pointer transition-colors group"
                    >
                      {/* Column 1: Account Name & Industry */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-md bg-slate-800 border border-slate-700/80 flex items-center justify-center font-bold text-slate-300 text-xs shrink-0 group-hover:border-cyan-500 transition-colors">
                            {account.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors flex items-center gap-1.5">
                              <span>{account.name}</span>
                              {hasExpansion && (
                                <span title="Expansion Signal Active">
                                  <Zap className="w-3 h-3 text-cyan-400 fill-cyan-400/20" />
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">
                              <span>{account.industry}</span>
                              <span aria-hidden="true"> · </span>
                              <span>{account.tier}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Column 2: ARR */}
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                        <div className="font-semibold text-white">
                          ${account.arr.toLocaleString()}
                        </div>
                        <div className="text-[10px] text-slate-500">USD / Year</div>
                      </td>

                      {/* Column 3: Health Score & Trend */}
                      <td className="py-3.5 px-4 text-center">
                        <div className="inline-flex items-center gap-1.5">
                          <span
                            className={`font-mono text-xs font-bold px-2 py-0.5 rounded border tabular-nums ${
                              isCritical
                                ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                                : isAtRisk
                                  ? 'bg-amber-950/80 border-amber-800 text-amber-300'
                                  : isHealthy
                                    ? 'bg-cyan-950/80 border-cyan-800 text-cyan-300'
                                    : 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
                            }`}
                          >
                            {account.compositeHealth}
                          </span>
                          <span className="text-slate-400">
                            {account.healthTrend === 'improving' ? (
                              <ArrowUpRight className="w-3 h-3 text-emerald-400" />
                            ) : account.healthTrend === 'declining' ? (
                              <ArrowDownRight className="w-3 h-3 text-rose-400" />
                            ) : (
                              <Minus className="w-3 h-3 text-slate-500" />
                            )}
                          </span>
                        </div>
                      </td>

                      {/* Column 4: Constituent Health Scores */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5 font-mono text-[11px] tabular-nums">
                          <span title="Product Adoption" className="text-slate-300">
                            {account.healthBreakdown.adoption}%
                          </span>
                          <span className="text-slate-600">/</span>
                          <span title="Executive Sentiment" className="text-slate-300">
                            {account.healthBreakdown.sentiment}%
                          </span>
                          <span className="text-slate-600">/</span>
                          <span title="Support Health" className="text-slate-300">
                            {account.healthBreakdown.support}%
                          </span>
                          <span className="text-slate-600">/</span>
                          <span title="Commercial Health" className="text-slate-300">
                            {account.healthBreakdown.commercial}%
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          Adopt / Sent / Supp / Comm
                        </div>
                      </td>

                      {/* Column 5: License Capacity / Utilization */}
                      <td className="py-3.5 px-4 min-w-[130px]">
                        <div className="flex items-center justify-between text-[11px] font-mono tabular-nums mb-1">
                          <span className="text-slate-300">
                            {account.licenses.activeSeats} / {account.licenses.totalSeats}
                          </span>
                          <span
                            className={
                              account.licenses.utilizationPercent >= 90
                                ? 'text-cyan-400 font-semibold'
                                : account.licenses.utilizationPercent < 50
                                  ? 'text-rose-400 font-semibold'
                                  : 'text-slate-400'
                            }
                          >
                            {account.licenses.utilizationPercent}%
                          </span>
                        </div>
                        <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div
                            style={{ width: `${Math.min(account.licenses.utilizationPercent, 100)}%` }}
                            className={`h-full rounded-full ${
                              account.licenses.utilizationPercent >= 90
                                ? 'bg-cyan-500'
                                : account.licenses.utilizationPercent < 50
                                  ? 'bg-rose-500'
                                  : 'bg-emerald-500'
                            }`}
                          />
                        </div>
                      </td>

                      {/* Column 6: Renewal Horizon */}
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                        <div
                          className={`font-semibold ${
                            account.daysToRenewal <= 30
                              ? 'text-rose-400'
                              : account.daysToRenewal <= 60
                                ? 'text-amber-400'
                                : 'text-slate-300'
                          }`}
                        >
                          {account.daysToRenewal} days
                        </div>
                        <div className="text-[10px] text-slate-500">{account.renewalDate}</div>
                      </td>

                      {/* Column 7: Status & CSM */}
                      <td className="py-3.5 px-4">
                        <div className="text-xs text-slate-200">
                          {account.csmName}
                        </div>
                        <div className="text-[11px] font-mono mt-0.5">
                          <span
                            className={
                              account.renewalLikelihood === 'At Risk'
                                ? 'text-rose-400 font-medium'
                                : account.renewalLikelihood === 'Likely'
                                  ? 'text-emerald-400'
                                  : 'text-amber-400'
                            }
                          >
                            {account.renewalLikelihood}
                          </span>
                          {hasPlaybook && (
                            <span className="text-slate-500 ml-1">· Playbook Active</span>
                          )}
                        </div>
                      </td>

                      {/* Column 8: Action button */}
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onOpenAccount(account.id);
                          }}
                          className="px-2.5 py-1 text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-cyan-950 hover:text-cyan-300 hover:border-cyan-800 border border-slate-700/80 rounded transition-colors whitespace-nowrap"
                        >
                          View 360
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
