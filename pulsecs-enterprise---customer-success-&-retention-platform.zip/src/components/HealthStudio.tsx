import React, { useState } from 'react';
import { useCS, calculateComposite } from '../context/CSContext';
import { HealthWeights } from '../types';
import { INITIAL_HEALTH_WEIGHTS } from '../data/mockData';
import { Sliders, RefreshCw, Check, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface HealthStudioProps {
  onOpenAccount: (accountId: string) => void;
}

export const HealthStudio: React.FC<HealthStudioProps> = ({ onOpenAccount }) => {
  const {
    accounts,
    healthWeights,
    updateHealthWeights,
    recalculateAllAccountsWithWeights,
  } = useCS();

  // Local sandbox weights for simulation
  const [testWeights, setTestWeights] = useState<HealthWeights>({ ...healthWeights });
  const [appliedNotice, setAppliedNotice] = useState(false);

  // Total weight check
  const totalWeight =
    testWeights.adoption +
    testWeights.sentiment +
    testWeights.support +
    testWeights.commercial;

  // Calculate simulated distribution
  const simulatedScores = accounts.map((acc) => {
    const currentScore = acc.compositeHealth;
    const simScore = calculateComposite(acc.healthBreakdown, testWeights);
    return {
      account: acc,
      current: currentScore,
      simulated: simScore,
      diff: simScore - currentScore,
    };
  });

  const simChampions = simulatedScores.filter((s) => s.simulated >= 85);
  const simHealthy = simulatedScores.filter((s) => s.simulated >= 70 && s.simulated < 85);
  const simAtRisk = simulatedScores.filter((s) => s.simulated >= 50 && s.simulated < 70);
  const simCritical = simulatedScores.filter((s) => s.simulated < 50);

  const handleApplyToLive = () => {
    recalculateAllAccountsWithWeights(testWeights);
    setAppliedNotice(true);
    setTimeout(() => setAppliedNotice(false), 2500);
  };

  const handleReset = () => {
    setTestWeights({ ...INITIAL_HEALTH_WEIGHTS });
    recalculateAllAccountsWithWeights(INITIAL_HEALTH_WEIGHTS);
  };

  return (
    <div className="space-y-6">
      {/* Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Health Model Studio & Engine Simulator
          </h1>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            Calibrate multi-dimensional health weightings and simulate real-time portfolio score shifts
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="px-3 py-1.5 text-xs text-slate-400 hover:text-white bg-slate-900 border border-slate-800 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset to Standard</span>
          </button>

          <button
            onClick={handleApplyToLive}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            {appliedNotice ? (
              <>
                <Check className="w-3.5 h-3.5 text-white" />
                <span>Weights Applied!</span>
              </>
            ) : (
              <>
                <Sliders className="w-3.5 h-3.5" />
                <span>Apply to Live Portfolio</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Simulator Sliders Card */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">
            Weight Distribution Matrix
          </h2>
          <span
            className={`text-xs font-mono font-semibold px-2 py-0.5 rounded ${
              totalWeight === 100
                ? 'text-emerald-400 bg-emerald-950/60 border border-emerald-800'
                : 'text-rose-400 bg-rose-950/60 border border-rose-800'
            }`}
          >
            Total Weight: {totalWeight}% (Target: 100%)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
          {/* Pillar 1: Adoption */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Product Adoption</span>
              <span className="font-mono text-cyan-400 font-bold tabular-nums">
                {testWeights.adoption}%
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="70"
              value={testWeights.adoption}
              onChange={(e) =>
                setTestWeights({ ...testWeights, adoption: Number(e.target.value) })
              }
              className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              DAU/MAU ratios, feature depth, active license fill.
            </p>
          </div>

          {/* Pillar 2: Sentiment */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Executive Sentiment</span>
              <span className="font-mono text-cyan-400 font-bold tabular-nums">
                {testWeights.sentiment}%
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="70"
              value={testWeights.sentiment}
              onChange={(e) =>
                setTestWeights({ ...testWeights, sentiment: Number(e.target.value) })
              }
              className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              Sponsor relationship, executive meeting cadence, CSAT.
            </p>
          </div>

          {/* Pillar 3: Support */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Support & SLAs</span>
              <span className="font-mono text-cyan-400 font-bold tabular-nums">
                {testWeights.support}%
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="70"
              value={testWeights.support}
              onChange={(e) =>
                setTestWeights({ ...testWeights, support: Number(e.target.value) })
              }
              className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              Ticket latency, unresolved P1s, engineering escalations.
            </p>
          </div>

          {/* Pillar 4: Commercial */}
          <div className="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200">Commercial Stability</span>
              <span className="font-mono text-cyan-400 font-bold tabular-nums">
                {testWeights.commercial}%
              </span>
            </div>
            <input
              type="range"
              min="5"
              max="70"
              value={testWeights.commercial}
              onChange={(e) =>
                setTestWeights({ ...testWeights, commercial: Number(e.target.value) })
              }
              className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-500 leading-tight">
              Contract tenure, invoice promptness, budget risk.
            </p>
          </div>
        </div>
      </div>

      {/* Simulated Distribution Barometer */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">
            Simulated Portfolio Distribution Under Test Weights
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            {accounts.length} total accounts
          </span>
        </div>

        {/* Visual Barometer */}
        <div className="h-3 w-full rounded-full bg-slate-800 flex overflow-hidden gap-0.5">
          <div
            style={{ width: `${(simChampions.length / accounts.length) * 100}%` }}
            className="bg-emerald-500 transition-all duration-300"
          />
          <div
            style={{ width: `${(simHealthy.length / accounts.length) * 100}%` }}
            className="bg-cyan-500 transition-all duration-300"
          />
          <div
            style={{ width: `${(simAtRisk.length / accounts.length) * 100}%` }}
            className="bg-amber-500 transition-all duration-300"
          />
          <div
            style={{ width: `${(simCritical.length / accounts.length) * 100}%` }}
            className="bg-rose-500 transition-all duration-300"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <span className="text-xs text-emerald-400 font-medium">Champion (85+)</span>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              {simChampions.length}{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((simChampions.length / accounts.length) * 100)}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <span className="text-xs text-cyan-400 font-medium">Healthy (70–84)</span>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              {simHealthy.length}{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((simHealthy.length / accounts.length) * 100)}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <span className="text-xs text-amber-400 font-medium">At Risk (50–69)</span>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              {simAtRisk.length}{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((simAtRisk.length / accounts.length) * 100)}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <span className="text-xs text-rose-400 font-medium">Critical (&lt;50)</span>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              {simCritical.length}{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((simCritical.length / accounts.length) * 100)}%)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Account Score Delta Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            Per-Account Simulated Score Variance
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            Click row to view full 360
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 font-mono uppercase text-[11px]">
                <th className="py-2.5 px-4">Account</th>
                <th className="py-2.5 px-4 text-right">Current Score</th>
                <th className="py-2.5 px-4 text-right">Simulated Score</th>
                <th className="py-2.5 px-4 text-right">Delta</th>
                <th className="py-2.5 px-4 text-right">ARR</th>
                <th className="py-2.5 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono tabular-nums">
              {simulatedScores.map((s) => (
                <tr
                  key={s.account.id}
                  onClick={() => onOpenAccount(s.account.id)}
                  className="hover:bg-slate-800/30 cursor-pointer transition-colors"
                >
                  <td className="py-2.5 px-4 font-sans font-medium text-slate-200">
                    {s.account.name}
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-400">
                    {s.current}
                  </td>
                  <td className="py-2.5 px-4 text-right font-bold text-white">
                    {s.simulated}
                  </td>
                  <td className="py-2.5 px-4 text-right">
                    <span
                      className={
                        s.diff > 0
                          ? 'text-emerald-400'
                          : s.diff < 0
                            ? 'text-rose-400'
                            : 'text-slate-500'
                      }
                    >
                      {s.diff > 0 ? `+${s.diff}` : s.diff}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 text-right text-slate-400">
                    ${(s.account.arr / 1000).toFixed(0)}k
                  </td>
                  <td className="py-2.5 px-4 text-right font-sans">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenAccount(s.account.id);
                      }}
                      className="text-xs text-cyan-400 hover:underline"
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
