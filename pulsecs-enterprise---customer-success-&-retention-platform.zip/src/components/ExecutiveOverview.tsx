import React from 'react';
import { useCS } from '../context/CSContext';
import {
  TrendingUp,
  AlertTriangle,
  Zap,
  CheckCircle2,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from 'lucide-react';

interface ExecutiveOverviewProps {
  onOpenAccount: (accountId: string) => void;
  onOpenPlaybook: () => void;
}

export const ExecutiveOverview: React.FC<ExecutiveOverviewProps> = ({
  onOpenAccount,
  onOpenPlaybook,
}) => {
  const { accounts, expansionSignals, playbooks, setActiveTab } = useCS();

  // Metric Computations
  const totalArr = accounts.reduce((acc, a) => acc + a.arr, 0);
  const avgHealth = Math.round(
    accounts.reduce((acc, a) => acc + a.compositeHealth, 0) / (accounts.length || 1)
  );

  const atRiskAccounts = accounts.filter(
    (a) => a.compositeHealth < 70 || a.renewalLikelihood === 'At Risk'
  );
  const atRiskArr = atRiskAccounts.reduce((acc, a) => acc + a.arr, 0);

  const expansionArr = expansionSignals
    .filter((s) => s.status !== 'Dismissed')
    .reduce((acc, s) => acc + s.potentialArr, 0);

  // Health tiers distribution
  const champions = accounts.filter((a) => a.compositeHealth >= 85);
  const healthy = accounts.filter((a) => a.compositeHealth >= 70 && a.compositeHealth < 85);
  const atRisk = accounts.filter((a) => a.compositeHealth >= 50 && a.compositeHealth < 70);
  const critical = accounts.filter((a) => a.compositeHealth < 50);

  // Urgent attention accounts
  const urgentAccounts = [...accounts]
    .filter((a) => a.compositeHealth < 70 || a.daysToRenewal <= 45)
    .sort((a, b) => a.compositeHealth - b.compositeHealth)
    .slice(0, 4);

  // Active playbooks count
  const activePlaybooksCount = playbooks.filter((p) => p.status === 'active').length;

  return (
    <div className="space-y-6">
      {/* Page Title & Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Executive Command Center
          </h1>
          <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-mono">
            <span>Portfolio: {accounts.length} Enterprise Accounts</span>
            <span aria-hidden="true">·</span>
            <span>Fiscal Period: Q4 2026</span>
            <span aria-hidden="true">·</span>
            <span>Live Health Telemetry</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('renewals')}
            className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700/80 rounded-lg hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-1.5"
          >
            <span>NRR Forecast: 118.4%</span>
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-400" />
          </button>
          <button
            onClick={() => setActiveTab('expansion')}
            className="px-3 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/60 border border-cyan-800/60 rounded-lg hover:bg-cyan-900/50 transition-colors flex items-center gap-1.5"
          >
            <span>{expansionSignals.filter((s) => s.status === 'New').length} New Signals</span>
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
          </button>
        </div>
      </div>

      {/* KPI Metrics Ribbon */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total Portfolio ARR */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 transition-colors hover:border-slate-700">
          <div className="text-xs text-slate-400 font-medium">Portfolio ARR</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            ${(totalArr / 1_000_000).toFixed(2)}M
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1.5 font-mono">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+14.2% YoY Growth</span>
          </div>
        </div>

        {/* Metric 2: Average Health Score */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 transition-colors hover:border-slate-700">
          <div className="text-xs text-slate-400 font-medium">Portfolio Health Score</div>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-bold text-white font-mono tabular-nums">
              {avgHealth}
            </span>
            <span className="text-xs text-slate-500 font-mono">/ 100</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-400 mt-1.5 font-mono">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+3 pts vs last month</span>
          </div>
        </div>

        {/* Metric 3: At-Risk ARR */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 transition-colors hover:border-slate-700">
          <div className="text-xs text-slate-400 font-medium">At-Risk ARR (Health &lt; 70)</div>
          <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums mt-1">
            ${(atRiskArr / 1_000).toFixed(0)}K
          </div>
          <div className="flex items-center gap-1.5 text-xs text-rose-400/80 mt-1.5 font-mono">
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>{atRiskAccounts.length} accounts flagged</span>
          </div>
        </div>

        {/* Metric 4: Expansion Pipeline */}
        <div className="bg-slate-900/70 border border-slate-800/80 rounded-xl p-4 transition-colors hover:border-slate-700">
          <div className="text-xs text-slate-400 font-medium">Identified Expansion ARR</div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-1">
            +${(expansionArr / 1_000).toFixed(0)}K
          </div>
          <div className="flex items-center gap-1.5 text-xs text-cyan-400 mt-1.5 font-mono">
            <Zap className="w-3.5 h-3.5" />
            <span>{expansionSignals.filter((s) => s.status !== 'Dismissed').length} active signals</span>
          </div>
        </div>
      </div>

      {/* Health Distribution & Playbooks Overview Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Health Distribution Barometer (2 cols on lg) */}
        <div className="lg:col-span-2 bg-slate-900/50 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-semibold text-white">
                Portfolio Health Distribution
              </h2>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                Weighted composite across Product Adoption, Executive Sentiment, Support SLAs, and Commercial Stability
              </div>
            </div>
            <button
              onClick={() => setActiveTab('health-studio')}
              className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
            >
              <span>Model Config</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Segmented Barometer */}
          <div className="h-3 w-full rounded-full bg-slate-800 flex overflow-hidden gap-0.5 mb-4">
            <div
              style={{ width: `${(champions.length / accounts.length) * 100}%` }}
              className="bg-emerald-500 transition-all duration-500"
              title={`Champions (85-100): ${champions.length} accounts`}
            />
            <div
              style={{ width: `${(healthy.length / accounts.length) * 100}%` }}
              className="bg-cyan-500 transition-all duration-500"
              title={`Healthy (70-84): ${healthy.length} accounts`}
            />
            <div
              style={{ width: `${(atRisk.length / accounts.length) * 100}%` }}
              className="bg-amber-500 transition-all duration-500"
              title={`At Risk (50-69): ${atRisk.length} accounts`}
            />
            <div
              style={{ width: `${(critical.length / accounts.length) * 100}%` }}
              className="bg-rose-500 transition-all duration-500"
              title={`Critical (<50): ${critical.length} accounts`}
            />
          </div>

          {/* Health Tier Legend & Breakdown Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-emerald-400 font-medium">Champion</span>
                <span className="text-xs text-slate-500 font-mono">85–100</span>
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
                {champions.length}{' '}
                <span className="text-xs text-slate-400 font-normal">
                  ({Math.round((champions.length / accounts.length) * 100)}%)
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                ${(champions.reduce((s, a) => s + a.arr, 0) / 1000).toFixed(0)}k ARR
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-cyan-400 font-medium">Healthy</span>
                <span className="text-xs text-slate-500 font-mono">70–84</span>
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
                {healthy.length}{' '}
                <span className="text-xs text-slate-400 font-normal">
                  ({Math.round((healthy.length / accounts.length) * 100)}%)
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                ${(healthy.reduce((s, a) => s + a.arr, 0) / 1000).toFixed(0)}k ARR
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-amber-400 font-medium">At Risk</span>
                <span className="text-xs text-slate-500 font-mono">50–69</span>
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
                {atRisk.length}{' '}
                <span className="text-xs text-slate-400 font-normal">
                  ({Math.round((atRisk.length / accounts.length) * 100)}%)
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                ${(atRisk.reduce((s, a) => s + a.arr, 0) / 1000).toFixed(0)}k ARR
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-rose-400 font-medium">Critical</span>
                <span className="text-xs text-slate-500 font-mono">&lt;50</span>
              </div>
              <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
                {critical.length}{' '}
                <span className="text-xs text-slate-400 font-normal">
                  ({Math.round((critical.length / accounts.length) * 100)}%)
                </span>
              </div>
              <div className="text-xs text-slate-400 font-mono mt-0.5">
                ${(critical.reduce((s, a) => s + a.arr, 0) / 1000).toFixed(0)}k ARR
              </div>
            </div>
          </div>
        </div>

        {/* Right: Operational Playbook Status */}
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-semibold text-white">Active Playbooks</h2>
              <button
                onClick={onOpenPlaybook}
                className="text-xs text-cyan-400 hover:text-cyan-300 font-medium flex items-center gap-1"
              >
                <span>View All ({playbooks.length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Automated retention and expansion execution workflows. Currently protecting{' '}
              <span className="font-mono text-white font-medium">
                ${(playbooks.filter((p) => p.status === 'active').reduce((s, p) => s + p.arrAtStake, 0) / 1000).toFixed(0)}k ARR
              </span>.
            </p>

            <div className="space-y-2.5 mt-4">
              {playbooks.slice(0, 3).map((pb) => {
                const completedTasks = pb.tasks.filter((t) => t.completed).length;
                const totalTasks = pb.tasks.length;
                const percent = Math.round((completedTasks / totalTasks) * 100);

                return (
                  <div
                    key={pb.id}
                    onClick={() => {
                      onOpenAccount(pb.targetAccountId);
                    }}
                    className="p-2.5 bg-slate-950/60 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-200 group-hover:text-cyan-300 transition-colors truncate max-w-[170px]">
                        {pb.title}
                      </span>
                      <span className="text-xs font-mono text-slate-400">
                        {completedTasks}/{totalTasks}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-slate-500 mt-1 font-mono">
                      <span>{pb.targetAccountName}</span>
                      <span>${(pb.arrAtStake / 1000).toFixed(0)}k</span>
                    </div>
                    {/* Mini progress */}
                    <div className="h-1.5 w-full bg-slate-800 rounded-full mt-2 overflow-hidden">
                      <div
                        style={{ width: `${percent}%` }}
                        className="h-full bg-cyan-500 rounded-full transition-all"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span className="font-mono">{activePlaybooksCount} active workflows</span>
            <button
              onClick={onOpenPlaybook}
              className="text-xs font-medium text-cyan-400 hover:underline"
            >
              + Launch Playbook
            </button>
          </div>
        </div>
      </div>

      {/* Critical Triage Queue / Accounts Needing Proactive Action */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-semibold text-white">
              Immediate Attention & Churn Risk Queue
            </h2>
            <div className="text-xs text-slate-400 mt-0.5">
              Prioritized by composite health score vulnerability and renewal contract proximity
            </div>
          </div>
          <button
            onClick={() => setActiveTab('accounts')}
            className="text-xs text-slate-300 hover:text-white font-medium flex items-center gap-1 font-mono"
          >
            <span>All Accounts ({accounts.length})</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-800/80">
          {urgentAccounts.map((account) => {
            const isCritical = account.compositeHealth < 50;
            const isAtRisk = account.compositeHealth >= 50 && account.compositeHealth < 70;

            return (
              <div
                key={account.id}
                onClick={() => onOpenAccount(account.id)}
                className="py-3 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-800/30 px-3 rounded-lg cursor-pointer transition-colors group"
              >
                <div className="flex items-start gap-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold font-mono text-sm shrink-0 border ${
                      isCritical
                        ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                        : isAtRisk
                          ? 'bg-amber-950/80 border-amber-800 text-amber-300'
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                    }`}
                  >
                    {account.compositeHealth}
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors">
                        {account.name}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        ${(account.arr / 1000).toFixed(0)}k ARR
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{account.csmName}</span>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono">Renewal in {account.daysToRenewal}d</span>
                      <span aria-hidden="true">·</span>
                      <span
                        className={
                          account.renewalLikelihood === 'At Risk'
                            ? 'text-rose-400 font-medium'
                            : 'text-amber-400'
                        }
                      >
                        {account.renewalLikelihood}
                      </span>
                    </div>

                    {account.riskSummary && (
                      <p className="text-xs text-slate-400/90 mt-1 line-clamp-1">
                        {account.riskSummary}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-4 shrink-0 justify-between md:justify-end">
                  <div className="text-right hidden sm:block font-mono text-xs">
                    <div className="text-slate-300">
                      Adoption: {account.licenses.utilizationPercent}%
                    </div>
                    <div className="text-slate-500">
                      Sentiment: {account.healthBreakdown.sentiment}/100
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenAccount(account.id);
                      }}
                      className="px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                    >
                      Inspect 360
                    </button>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-slate-300 transition-colors" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
