import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import { CustomerTier } from '../types';
import { X, Plus, Building2 } from 'lucide-react';

interface AddAccountModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (newAccountId: string) => void;
}

export const AddAccountModal: React.FC<AddAccountModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { addNewAccount, accounts } = useCS();

  const [name, setName] = useState('');
  const [industry, setIndustry] = useState('SaaS & Software');
  const [arr, setArr] = useState(250000);
  const [tier, setTier] = useState<CustomerTier>('Enterprise');
  const [csmName, setCsmName] = useState('Marcus Vance');
  const [renewalDate, setRenewalDate] = useState('2027-04-30');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    addNewAccount({
      name: name.trim(),
      industry,
      arr: Number(arr),
      tier,
      csmName,
      renewalDate,
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-4 shadow-2xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Onboard New Customer Account</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
          <div>
            <label className="text-slate-300 font-medium block mb-1">Company / Account Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Acme Corporation"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Annual Recurring Rev (ARR $)</label>
              <input
                type="number"
                required
                step="5000"
                min="10000"
                value={arr}
                onChange={(e) => setArr(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 font-mono focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Contract Tier</label>
              <select
                value={tier}
                onChange={(e) => setTier(e.target.value as CustomerTier)}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none"
              >
                <option value="Strategic">Strategic</option>
                <option value="Enterprise">Enterprise</option>
                <option value="Mid-Market">Mid-Market</option>
                <option value="Growth">Growth</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Industry</label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-slate-300 font-medium block mb-1">Assigned CSM</label>
              <select
                value={csmName}
                onChange={(e) => setCsmName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 focus:border-cyan-500 focus:outline-none"
              >
                <option value="Marcus Vance">Marcus Vance</option>
                <option value="Sarah Jenkins">Sarah Jenkins</option>
                <option value="Elena Rostova">Elena Rostova</option>
              </select>
            </div>
          </div>

          <div>
            <label className="text-slate-300 font-medium block mb-1">Next Renewal Date</label>
            <input
              type="date"
              value={renewalDate}
              onChange={(e) => setRenewalDate(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5 font-mono focus:border-cyan-500 focus:outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm"
            >
              Onboard Account
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
