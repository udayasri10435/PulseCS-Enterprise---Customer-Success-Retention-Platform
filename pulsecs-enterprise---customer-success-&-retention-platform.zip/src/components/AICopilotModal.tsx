import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import {
  requestAIDiagnostic,
  requestAIRenewalPitch,
  requestAIExpansionStrategy,
  AIDiagnosticResult,
  AIRenewalPitchResult,
  AIExpansionResult,
} from '../services/aiService';
import {
  X,
  Sparkles,
  AlertTriangle,
  TrendingUp,
  Zap,
  Copy,
  ArrowRight,
  Check,
} from 'lucide-react';

interface AICopilotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAccount: (accountId: string) => void;
}

export const AICopilotModal: React.FC<AICopilotModalProps> = ({
  isOpen,
  onClose,
  onOpenAccount,
}) => {
  const { accounts } = useCS();

  const [selectedAccountId, setSelectedAccountId] = useState(accounts[0]?.id || '');
  const [taskType, setTaskType] = useState<'diagnostic' | 'pitch' | 'expansion'>('diagnostic');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  // Results
  const [diagnosticResult, setDiagnosticResult] = useState<AIDiagnosticResult | null>(null);
  const [renewalPitchResult, setRenewalPitchResult] = useState<AIRenewalPitchResult | null>(null);
  const [expansionResult, setExpansionResult] = useState<AIExpansionResult | null>(null);

  if (!isOpen) return null;

  const currentAccount = accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  const handleGenerate = async () => {
    if (!currentAccount) return;
    setLoading(true);
    setDiagnosticResult(null);
    setRenewalPitchResult(null);
    setExpansionResult(null);

    try {
      if (taskType === 'diagnostic') {
        const res = await requestAIDiagnostic(currentAccount);
        setDiagnosticResult(res);
      } else if (taskType === 'pitch') {
        const res = await requestAIRenewalPitch(currentAccount);
        setRenewalPitchResult(res);
      } else {
        const res = await requestAIExpansionStrategy(currentAccount);
        setExpansionResult(res);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl my-auto max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-800 flex items-center justify-center text-cyan-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">PulseCS Executive Intelligence Copilot</h3>
              <div className="text-[11px] text-slate-400 font-mono">
                Model: Gemini 3.8 Flash · Telemetry-Grounded Customer Intelligence
              </div>
            </div>
          </div>

          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Input Configuration Ribbon */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/40 grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Target Account</label>
            <select
              value={selectedAccountId}
              onChange={(e) => {
                setSelectedAccountId(e.target.value);
                setDiagnosticResult(null);
                setRenewalPitchResult(null);
                setExpansionResult(null);
              }}
              className="w-full bg-slate-900 border border-slate-800 text-xs text-white rounded-lg p-2 font-mono"
            >
              {accounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name} (${(a.arr / 1000).toFixed(0)}k ARR · Health: {a.compositeHealth})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Intelligence Objective</label>
            <select
              value={taskType}
              onChange={(e) => {
                setTaskType(e.target.value as any);
                setDiagnosticResult(null);
                setRenewalPitchResult(null);
                setExpansionResult(null);
              }}
              className="w-full bg-slate-900 border border-slate-800 text-xs text-white rounded-lg p-2"
            >
              <option value="diagnostic">Retention & Churn Risk Diagnostic</option>
              <option value="pitch">Executive Renewal Pitch & Quantified ROI</option>
              <option value="expansion">Account Expansion & Upsell Strategy</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="w-full py-2 px-4 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{loading ? 'Synthesizing...' : 'Run Analysis'}</span>
            </button>
          </div>
        </div>

        {/* Results Container */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          {loading && (
            <div className="p-16 text-center space-y-3">
              <div className="inline-block animate-spin w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full" />
              <p className="text-xs text-slate-400 font-mono">
                Evaluating license utilization, sentiment signals, and historical support records...
              </p>
            </div>
          )}

          {!loading && !diagnosticResult && !renewalPitchResult && !expansionResult && (
            <div className="p-12 text-center border border-slate-800 rounded-xl bg-slate-950/30 space-y-3">
              <Sparkles className="w-8 h-8 text-cyan-400 mx-auto" />
              <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                Select any enterprise account and intelligence objective above to generate executive-ready churn diagnostics, renewal justification decks, or expansion strategies.
              </p>
              <button
                onClick={handleGenerate}
                className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg"
              >
                Synthesize Analysis Now
              </button>
            </div>
          )}

          {/* Render Diagnostic */}
          {!loading && diagnosticResult && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300 font-mono">
                    CHURN RISK LEVEL: {diagnosticResult.churnRiskLevel.toUpperCase()}
                  </span>
                  <button
                    onClick={() => handleCopy(diagnosticResult.summary)}
                    className="text-cyan-400 hover:underline flex items-center gap-1 font-mono text-[11px]"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copied ? 'Copied!' : 'Copy Summary'}</span>
                  </button>
                </div>
                <p className="text-slate-200 leading-relaxed font-sans">{diagnosticResult.summary}</p>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                <div className="font-bold text-slate-300">Root Cause Vulnerabilities:</div>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {diagnosticResult.rootCauses.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                <div className="font-bold text-slate-300">30-Day Recovery Schedule:</div>
                <div className="divide-y divide-slate-800/80">
                  {diagnosticResult.immediateActions.map((act, i) => (
                    <div key={i} className="py-2">
                      <strong className="text-cyan-400 font-mono">{act.dayRange}:</strong>{' '}
                      <span className="text-slate-200">{act.action}</span>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Outcome: {act.expectedOutcome} · Owner: {act.owner}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Render Renewal Pitch */}
          {!loading && renewalPitchResult && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                <h4 className="font-bold text-white text-sm">{renewalPitchResult.headline}</h4>
                <p className="text-slate-300 leading-relaxed">{renewalPitchResult.quantifiedImpactSummary}</p>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                <div className="font-bold text-slate-300">Quantified Business Impact Highlights:</div>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {renewalPitchResult.deliveredValueHighlights.map((h, i) => (
                    <li key={i}>{h}</li>
                  ))}
                </ul>
              </div>

              <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-300">Draft Renewal Email to Executive Sponsor</span>
                  <button
                    onClick={() => handleCopy(renewalPitchResult.emailDraftToSponsor)}
                    className="text-cyan-400 hover:underline flex items-center gap-1 font-mono text-[11px]"
                  >
                    <Copy className="w-3 h-3" />
                    <span>{copied ? 'Copied Email' : 'Copy Email'}</span>
                  </button>
                </div>
                <pre className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                  {renewalPitchResult.emailDraftToSponsor}
                </pre>
              </div>
            </div>
          )}

          {/* Render Expansion */}
          {!loading && expansionResult && (
            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-cyan-400 font-mono">{expansionResult.expansionAngle}</span>
                  <span className="font-bold text-emerald-400 font-mono">{expansionResult.projectedArrUplift}</span>
                </div>
                <h4 className="font-semibold text-white">{expansionResult.recommendedPackage}</h4>
              </div>

              <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                <div className="font-bold text-slate-300">Strategic Business Case Points:</div>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  {expansionResult.businessCasePoints.map((pt, i) => (
                    <li key={i}>{pt}</li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              onClose();
              onOpenAccount(currentAccount.id);
            }}
            className="text-cyan-400 hover:underline flex items-center gap-1 font-mono"
          >
            <span>Open {currentAccount.name} 360 Workspace</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs bg-slate-800 hover:bg-slate-700 text-white rounded-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
