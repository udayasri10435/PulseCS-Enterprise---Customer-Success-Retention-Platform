import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import { Playbook, PlaybookCategory } from '../types';
import { PLAYBOOK_TEMPLATES } from '../data/mockData';
import {
  ShieldCheck,
  CheckCircle2,
  Clock,
  Plus,
  Filter,
  AlertTriangle,
  TrendingUp,
  User,
  Calendar,
  X,
} from 'lucide-react';

interface PlaybooksHubProps {
  onOpenAccount: (accountId: string) => void;
}

export const PlaybooksHub: React.FC<PlaybooksHubProps> = ({ onOpenAccount }) => {
  const { playbooks, accounts, togglePlaybookTask, launchPlaybook } = useCS();

  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'completed'>('active');

  // Modal for launching a new playbook
  const [showLaunchModal, setShowLaunchModal] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState(PLAYBOOK_TEMPLATES[0].id);
  const [selectedAccountId, setSelectedAccountId] = useState(accounts[0]?.id || '');
  const [customReason, setCustomReason] = useState('');

  // Calculations
  const activePlaybooks = playbooks.filter((p) => p.status === 'active');
  const totalArrProtected = activePlaybooks.reduce((acc, p) => acc + p.arrAtStake, 0);

  const allTasks = playbooks.flatMap((p) => p.tasks);
  const pendingTasks = allTasks.filter((t) => !t.completed);

  // Filtered Playbooks
  const filteredPlaybooks = playbooks.filter((p) => {
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (categoryFilter !== 'all' && p.category !== categoryFilter) return false;
    return true;
  });

  const handleLaunchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAccountId || !selectedTemplateId) return;
    launchPlaybook(selectedTemplateId, selectedAccountId, customReason.trim());
    setCustomReason('');
    setShowLaunchModal(false);
  };

  return (
    <div className="space-y-6">
      {/* Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Customer Success Playbooks Hub
          </h1>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            {activePlaybooks.length} Active Automation Workflows Protecting ${(totalArrProtected / 1_000_000).toFixed(2)}M ARR
          </div>
        </div>

        <button
          onClick={() => setShowLaunchModal(true)}
          className="px-3.5 py-1.5 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Launch New Playbook</span>
        </button>
      </div>

      {/* KPI Stats Ribbon */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">ARR at Stake in Playbooks</div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums mt-1">
            ${(totalArrProtected / 1_000).toFixed(0)}K
          </div>
          <div className="text-xs text-emerald-400 mt-1 font-mono">
            {activePlaybooks.length} active engagements
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Pending Action Tasks</div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-1">
            {pendingTasks.length}
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Across {accounts.length} enterprise accounts
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Playbook Execution Success Rate</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">
            91.4%
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Churn prevention rate in last 90 days
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/40 p-2.5 rounded-xl border border-slate-800">
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setStatusFilter('active')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              statusFilter === 'active'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Active ({playbooks.filter((p) => p.status === 'active').length})
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              statusFilter === 'completed'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Completed ({playbooks.filter((p) => p.status === 'completed').length})
          </button>
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
              statusFilter === 'all'
                ? 'bg-slate-800 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Workflows ({playbooks.length})
          </button>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-1 text-xs">
          <span className="text-slate-500 font-mono hidden sm:inline">Category:</span>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All Categories</option>
            <option value="Churn Prevention">Churn Prevention</option>
            <option value="Executive Alignment">Executive Alignment</option>
            <option value="Renewal Acceleration">Renewal Acceleration</option>
            <option value="Expansion Play">Expansion Play</option>
          </select>
        </div>
      </div>

      {/* Playbooks List Grid */}
      <div className="space-y-4">
        {filteredPlaybooks.length === 0 ? (
          <div className="p-12 text-center border border-slate-800 rounded-xl bg-slate-900/30 text-xs text-slate-400">
            No playbooks found matching current filters.
          </div>
        ) : (
          filteredPlaybooks.map((pb) => {
            const completedCount = pb.tasks.filter((t) => t.completed).length;
            const totalCount = pb.tasks.length;
            const percent = Math.round((completedCount / totalCount) * 100);

            return (
              <div
                key={pb.id}
                className="bg-slate-900/60 border border-slate-800 rounded-xl p-5 space-y-4 transition-all hover:border-slate-700"
              >
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="text-sm font-bold text-white">{pb.title}</span>
                      <span className="text-[10px] text-cyan-300 bg-cyan-950/60 border border-cyan-800/80 px-2 py-0.5 rounded font-mono">
                        {pb.category}
                      </span>
                      {pb.status === 'completed' && (
                        <span className="text-[10px] text-emerald-300 bg-emerald-950/60 border border-emerald-800 px-2 py-0.5 rounded font-mono">
                          Completed
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-mono">
                      <span>Target Account:</span>
                      <button
                        onClick={() => onOpenAccount(pb.targetAccountId)}
                        className="text-cyan-400 hover:underline font-semibold"
                      >
                        {pb.targetAccountName}
                      </button>
                      <span aria-hidden="true">·</span>
                      <span>ARR at stake: ${(pb.arrAtStake / 1000).toFixed(0)}k</span>
                      <span aria-hidden="true">·</span>
                      <span>Started: {pb.startedAt}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right font-mono text-xs">
                      <span className="text-white font-bold">{percent}%</span>
                      <span className="text-slate-500 ml-1">
                        ({completedCount}/{totalCount} tasks)
                      </span>
                    </div>
                  </div>
                </div>

                {/* Trigger context */}
                <p className="text-xs text-slate-400 leading-relaxed font-sans">
                  <strong className="text-slate-300">Trigger Reason:</strong> {pb.triggerReason}
                </p>

                {/* Progress bar */}
                <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${percent}%` }}
                    className={`h-full rounded-full transition-all duration-300 ${
                      pb.status === 'completed' ? 'bg-emerald-500' : 'bg-cyan-500'
                    }`}
                  />
                </div>

                {/* Task Checklist */}
                <div className="divide-y divide-slate-800/80 bg-slate-950/40 border border-slate-800/80 rounded-lg px-4">
                  {pb.tasks.map((task) => (
                    <div
                      key={task.id}
                      className="py-3 flex items-start gap-3 text-xs transition-colors hover:bg-slate-800/20"
                    >
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => togglePlaybookTask(pb.id, task.id)}
                        className="mt-0.5 rounded text-cyan-600 focus:ring-0 cursor-pointer"
                      />
                      <div className="flex-1">
                        <div
                          className={`font-medium ${
                            task.completed ? 'line-through text-slate-500' : 'text-slate-200'
                          }`}
                        >
                          {task.title}
                        </div>
                        <div className="text-slate-400 text-[11px] mt-0.5">
                          {task.description}
                        </div>
                      </div>
                      <div className="text-right text-[11px] font-mono text-slate-400 shrink-0">
                        <div>Due: {task.dueDate}</div>
                        <div className="text-slate-500">{task.assignee}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal: Launch New Playbook */}
      {showLaunchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Launch Proactive Playbook</h3>
              <button
                onClick={() => setShowLaunchModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleLaunchSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-300 font-medium block mb-1">
                  Select Target Customer Account
                </label>
                <select
                  value={selectedAccountId}
                  onChange={(e) => setSelectedAccountId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5"
                  required
                >
                  {accounts.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name} (${(a.arr / 1000).toFixed(0)}k ARR · Health: {a.compositeHealth})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">
                  Playbook Template
                </label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5"
                  required
                >
                  {PLAYBOOK_TEMPLATES.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.category})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-300 font-medium block mb-1">
                  Specific Trigger Context or Rationale
                </label>
                <textarea
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  rows={2}
                  placeholder="e.g. Exec sponsor left company, low feature adoption, renewal approaching in 60d..."
                  className="w-full bg-slate-950 border border-slate-800 text-white rounded-lg p-2.5"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowLaunchModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm"
                >
                  Launch Playbook Tasks
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
