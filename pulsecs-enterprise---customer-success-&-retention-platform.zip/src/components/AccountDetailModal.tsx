import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import { Account, RenewalLikelihood, Touchpoint, Stakeholder } from '../types';
import { PLAYBOOK_TEMPLATES } from '../data/mockData';
import {
  requestAIDiagnostic,
  requestAIRenewalPitch,
  requestAIExpansionStrategy,
  AIDiagnosticResult,
  AIRenewalPitchResult,
  AIExpansionResult,
} from '../services/aiService';
import {
  X,
  Activity,
  Users,
  ShieldCheck,
  Calendar,
  Sparkles,
  Zap,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Copy,
  Plus,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

interface AccountDetailModalProps {
  account: Account;
  onClose: () => void;
}

export const AccountDetailModal: React.FC<AccountDetailModalProps> = ({
  account,
  onClose,
}) => {
  const {
    updateAccountHealth,
    updateRenewalLikelihood,
    addTouchpoint,
    addStakeholder,
    updateAccountNotes,
    playbooks,
    togglePlaybookTask,
    launchPlaybook,
  } = useCS();

  const [activeTab, setActiveTab] = useState<'health' | 'stakeholders' | 'playbooks' | 'touchpoints' | 'copilot'>('health');

  // Form states
  const [showAddTouchpoint, setShowAddTouchpoint] = useState(false);
  const [tpType, setTpType] = useState<Touchpoint['type']>('CSM Check-in');
  const [tpSummary, setTpSummary] = useState('');
  const [tpOutcome, setTpOutcome] = useState<Touchpoint['outcome']>('Positive');

  const [showAddStakeholder, setShowAddStakeholder] = useState(false);
  const [stkName, setStkName] = useState('');
  const [stkRole, setStkRole] = useState('');
  const [stkEmail, setStkEmail] = useState('');
  const [stkSentiment, setStkSentiment] = useState<Stakeholder['sentiment']>('Positive');
  const [stkIsExec, setStkIsExec] = useState(false);

  // AI Copilot state
  const [aiLoading, setAiLoading] = useState(false);
  const [diagnosticResult, setDiagnosticResult] = useState<AIDiagnosticResult | null>(null);
  const [renewalPitchResult, setRenewalPitchResult] = useState<AIRenewalPitchResult | null>(null);
  const [expansionResult, setExpansionResult] = useState<AIExpansionResult | null>(null);
  const [copilotView, setCopilotView] = useState<'diagnostic' | 'pitch' | 'expansion'>('diagnostic');
  const [copyFeedback, setCopyFeedback] = useState(false);

  // Playbook launcher inside modal
  const [selectedTemplateId, setSelectedTemplateId] = useState(PLAYBOOK_TEMPLATES[0].id);

  // Linked playbooks for this account
  const accountPlaybooks = playbooks.filter((p) => p.targetAccountId === account.id);

  // Health Score styling
  const isCritical = account.compositeHealth < 50;
  const isAtRisk = account.compositeHealth >= 50 && account.compositeHealth < 70;
  const isHealthy = account.compositeHealth >= 70 && account.compositeHealth < 85;

  // Handlers for AI
  const handleRunDiagnostic = async () => {
    setActiveTab('copilot');
    setCopilotView('diagnostic');
    setAiLoading(true);
    try {
      const res = await requestAIDiagnostic(account);
      setDiagnosticResult(res);
    } finally {
      setAiLoading(false);
    }
  };

  const handleRunRenewalPitch = async () => {
    setActiveTab('copilot');
    setCopilotView('pitch');
    setAiLoading(true);
    try {
      const res = await requestAIRenewalPitch(account);
      setRenewalPitchResult(res);
    } finally {
      setAiLoading(false);
    }
  };

  const handleRunExpansion = async () => {
    setActiveTab('copilot');
    setCopilotView('expansion');
    setAiLoading(true);
    try {
      const res = await requestAIExpansionStrategy(account);
      setExpansionResult(res);
    } finally {
      setAiLoading(false);
    }
  };

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopyFeedback(true);
    setTimeout(() => setCopyFeedback(false), 2000);
  };

  const handleSaveTouchpoint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tpSummary.trim()) return;
    addTouchpoint(account.id, {
      date: new Date().toISOString().split('T')[0],
      type: tpType,
      summary: tpSummary.trim(),
      author: account.csmName,
      outcome: tpOutcome,
    });
    setTpSummary('');
    setShowAddTouchpoint(false);
  };

  const handleSaveStakeholder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stkName.trim()) return;
    addStakeholder(account.id, {
      name: stkName.trim(),
      role: stkRole.trim() || 'Stakeholder',
      email: stkEmail.trim() || `${stkName.toLowerCase().replace(/\s+/g, '.')}@${account.domain}`,
      sentiment: stkSentiment,
      lastEngaged: new Date().toISOString().split('T')[0],
      isExecSponsor: stkIsExec,
    });
    setStkName('');
    setStkRole('');
    setStkEmail('');
    setShowAddStakeholder(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl my-auto max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Top Header Ribbon */}
        <div className="p-5 border-b border-slate-800 bg-slate-950/70 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div
              className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold font-mono text-lg shrink-0 border ${
                isCritical
                  ? 'bg-rose-950/80 border-rose-800 text-rose-300'
                  : isAtRisk
                    ? 'bg-amber-950/80 border-amber-800 text-amber-300'
                    : isHealthy
                      ? 'bg-cyan-950/80 border-cyan-800 text-cyan-300'
                      : 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
              }`}
            >
              {account.compositeHealth}
            </div>

            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-xl font-bold text-white tracking-tight">{account.name}</h2>
                <span className="text-xs text-slate-400 font-mono">
                  ${account.arr.toLocaleString()} ARR
                </span>
                <span className="text-xs text-slate-500 font-mono">· {account.industry}</span>
              </div>

              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1 font-mono">
                <span>CSM: {account.csmName}</span>
                <span aria-hidden="true">·</span>
                <span>Renewal: {account.renewalDate} ({account.daysToRenewal}d)</span>
                <span aria-hidden="true">·</span>
                <div className="inline-flex items-center gap-1.5">
                  <span className="text-slate-400 font-sans">Status:</span>
                  <select
                    value={account.renewalLikelihood}
                    onChange={(e) =>
                      updateRenewalLikelihood(account.id, e.target.value as RenewalLikelihood)
                    }
                    className="bg-slate-900 border border-slate-700 text-white rounded px-2 py-0.5 text-xs font-mono focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="Likely">Likely</option>
                    <option value="Under Negotiation">Under Negotiation</option>
                    <option value="At Risk">At Risk</option>
                    <option value="Won">Won</option>
                    <option value="Churned">Churned</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleRunDiagnostic}
              className="px-3 py-1.5 text-xs font-medium text-cyan-300 bg-cyan-950/80 border border-cyan-800 rounded-lg hover:bg-cyan-900 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>AI Diagnostic</span>
            </button>

            <button
              onClick={handleRunRenewalPitch}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800 border border-slate-700 rounded-lg hover:bg-slate-700 hover:text-white transition-colors"
            >
              Renewal Pitch
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors ml-2"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="px-5 border-b border-slate-800 bg-slate-950/40 flex items-center gap-1 overflow-x-auto no-scrollbar">
          {[
            { id: 'health', label: 'Health & Telemetry', icon: <Activity className="w-3.5 h-3.5" /> },
            { id: 'stakeholders', label: `Stakeholders (${account.stakeholders.length})`, icon: <Users className="w-3.5 h-3.5" /> },
            { id: 'playbooks', label: `Playbooks (${accountPlaybooks.length})`, icon: <ShieldCheck className="w-3.5 h-3.5" /> },
            { id: 'touchpoints', label: `Timeline (${account.touchpoints.length})`, icon: <Calendar className="w-3.5 h-3.5" /> },
            { id: 'copilot', label: 'AI CS Copilot', icon: <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> },
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 py-3 px-3 text-xs font-medium border-b-2 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-cyan-500 text-cyan-300'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body Viewports */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: Health Diagnostic & Drivers */}
          {activeTab === 'health' && (
            <div className="space-y-6">
              {/* Pillar Sliders Grid */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-white">
                    Multi-Dimensional Health Score Engine
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">
                    Composite Score: {account.compositeHealth}/100
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Driver 1: Adoption */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">1. Product Adoption (35%)</span>
                      <span className="font-mono text-cyan-400 font-bold tabular-nums">
                        {account.healthBreakdown.adoption}/100
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={account.healthBreakdown.adoption}
                      onChange={(e) =>
                        updateAccountHealth(account.id, { adoption: Number(e.target.value) })
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>DAU/MAU: {(account.licenses.dauToMauRatio * 100).toFixed(0)}%</span>
                      <span>Utilization: {account.licenses.utilizationPercent}%</span>
                    </div>
                  </div>

                  {/* Driver 2: Sentiment */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">2. Executive Sentiment (25%)</span>
                      <span className="font-mono text-cyan-400 font-bold tabular-nums">
                        {account.healthBreakdown.sentiment}/100
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={account.healthBreakdown.sentiment}
                      onChange={(e) =>
                        updateAccountHealth(account.id, { sentiment: Number(e.target.value) })
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Stakeholders: {account.stakeholders.length} mapped</span>
                      <span>Exec Sponsor: {account.stakeholders.some((s) => s.isExecSponsor) ? 'Engaged' : 'Departed'}</span>
                    </div>
                  </div>

                  {/* Driver 3: Support */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">3. Support & SLA Health (20%)</span>
                      <span className="font-mono text-cyan-400 font-bold tabular-nums">
                        {account.healthBreakdown.support}/100
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={account.healthBreakdown.support}
                      onChange={(e) =>
                        updateAccountHealth(account.id, { support: Number(e.target.value) })
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Escalated P1s: 0 active</span>
                      <span>Resolution SLA: 98.4%</span>
                    </div>
                  </div>

                  {/* Driver 4: Commercial */}
                  <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">4. Commercial Health (20%)</span>
                      <span className="font-mono text-cyan-400 font-bold tabular-nums">
                        {account.healthBreakdown.commercial}/100
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={account.healthBreakdown.commercial}
                      onChange={(e) =>
                        updateAccountHealth(account.id, { commercial: Number(e.target.value) })
                      }
                      className="w-full accent-cyan-500 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                    <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono">
                      <span>Contract tenure: 24 mos</span>
                      <span>Invoice aging: 0 days</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* License Capacity & Feature Telemetry */}
              <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-white">License & Feature Telemetry</h4>
                  <div className="text-xs text-slate-400 font-mono">
                    {account.licenses.activeSeats} of {account.licenses.totalSeats} seats assigned
                  </div>
                </div>

                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${account.licenses.utilizationPercent}%` }}
                    className={`h-full rounded-full transition-all ${
                      account.licenses.utilizationPercent >= 90
                        ? 'bg-cyan-500'
                        : account.licenses.utilizationPercent < 50
                          ? 'bg-rose-500'
                          : 'bg-emerald-500'
                    }`}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                  <div>
                    <div className="text-xs font-semibold text-slate-300 mb-2">
                      Heavily Adopted Features
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {account.licenses.topFeaturesUsed.map((feat) => (
                        <span
                          key={feat}
                          className="px-2.5 py-1 text-xs bg-slate-900 border border-slate-800 text-slate-200 rounded-md"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-semibold text-slate-300 mb-2">
                      Underutilized Modules (Expansion / Enablement Targets)
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {account.licenses.underutilizedFeatures.map((feat) => (
                        <span
                          key={feat}
                          className="px-2.5 py-1 text-xs bg-amber-950/40 border border-amber-900/60 text-amber-300 rounded-md"
                        >
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Risk Context & Notes */}
              <div className="bg-slate-950/50 border border-slate-800 rounded-xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-white">CSM Assessment & Context Notes</h4>
                  <span className="text-[11px] text-slate-500 font-mono">Auto-saved</span>
                </div>
                <textarea
                  value={account.notes}
                  onChange={(e) => updateAccountNotes(account.id, e.target.value)}
                  rows={3}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  placeholder="Record strategic account observations, procurement notes, or risk blockers..."
                />
              </div>
            </div>
          )}

          {/* TAB 2: Stakeholders */}
          {activeTab === 'stakeholders' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Stakeholder Relationship Map</h3>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Track executive alignment, champion engagement, and potential risk detractors
                  </div>
                </div>
                <button
                  onClick={() => setShowAddStakeholder(!showAddStakeholder)}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Stakeholder</span>
                </button>
              </div>

              {/* Add Stakeholder Form */}
              {showAddStakeholder && (
                <form
                  onSubmit={handleSaveStakeholder}
                  className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={stkName}
                      onChange={(e) => setStkName(e.target.value)}
                      required
                      className="px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-md text-white"
                    />
                    <input
                      type="text"
                      placeholder="Title / Role (e.g. VP Engineering)"
                      value={stkRole}
                      onChange={(e) => setStkRole(e.target.value)}
                      className="px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-md text-white"
                    />
                    <input
                      type="email"
                      placeholder="Work Email"
                      value={stkEmail}
                      onChange={(e) => setStkEmail(e.target.value)}
                      className="px-3 py-1.5 text-xs bg-slate-900 border border-slate-800 rounded-md text-white"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-4 text-xs text-slate-300">
                      <label className="flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={stkIsExec}
                          onChange={(e) => setStkIsExec(e.target.checked)}
                          className="rounded text-cyan-600"
                        />
                        <span>Executive Sponsor</span>
                      </label>

                      <div className="flex items-center gap-1">
                        <span>Sentiment:</span>
                        <select
                          value={stkSentiment}
                          onChange={(e) => setStkSentiment(e.target.value as any)}
                          className="bg-slate-900 border border-slate-800 text-xs text-slate-200 rounded px-2 py-0.5"
                        >
                          <option value="Champion">Champion</option>
                          <option value="Positive">Positive</option>
                          <option value="Neutral">Neutral</option>
                          <option value="Detractor">Detractor</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setShowAddStakeholder(false)}
                        className="px-3 py-1 text-xs text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="px-3 py-1 text-xs bg-cyan-600 text-white rounded hover:bg-cyan-500"
                      >
                        Save
                      </button>
                    </div>
                  </div>
                </form>
              )}

              {/* Stakeholders List */}
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-xl overflow-hidden bg-slate-950/40">
                {account.stakeholders.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    No stakeholders logged yet for this account.
                  </div>
                ) : (
                  account.stakeholders.map((stk) => (
                    <div key={stk.id} className="p-4 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-slate-300 text-xs">
                          {stk.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-semibold text-white">{stk.name}</span>
                            {stk.isExecSponsor && (
                              <span className="text-[10px] text-cyan-400 bg-cyan-950/60 border border-cyan-800/80 px-1.5 py-0.2 rounded font-mono">
                                Exec Sponsor
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            <span>{stk.role}</span>
                            <span aria-hidden="true"> · </span>
                            <span>{stk.email}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-mono">
                        <span
                          className={
                            stk.sentiment === 'Champion'
                              ? 'text-emerald-400'
                              : stk.sentiment === 'Positive'
                                ? 'text-cyan-400'
                                : stk.sentiment === 'Detractor'
                                  ? 'text-rose-400 font-bold'
                                  : 'text-slate-400'
                          }
                        >
                          {stk.sentiment}
                        </span>
                        <span className="text-slate-500 hidden sm:inline">
                          Touched: {stk.lastEngaged}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* TAB 3: Playbooks */}
          {activeTab === 'playbooks' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Active Account Playbooks</h3>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Automated workflows executing to protect or expand this account
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedTemplateId}
                    onChange={(e) => setSelectedTemplateId(e.target.value)}
                    className="text-xs bg-slate-900 border border-slate-800 text-slate-300 rounded-lg px-2.5 py-1.5"
                  >
                    {PLAYBOOK_TEMPLATES.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <button
                    onClick={() => launchPlaybook(selectedTemplateId, account.id)}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors flex items-center gap-1.5"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Launch</span>
                  </button>
                </div>
              </div>

              {accountPlaybooks.length === 0 ? (
                <div className="p-8 text-center border border-slate-800 rounded-xl bg-slate-950/40 space-y-2">
                  <p className="text-xs text-slate-400">
                    No active playbooks currently running for {account.name}.
                  </p>
                  <button
                    onClick={() => launchPlaybook(selectedTemplateId, account.id)}
                    className="text-xs text-cyan-400 hover:underline"
                  >
                    Launch a recommended playbook now
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {accountPlaybooks.map((pb) => {
                    const completedCount = pb.tasks.filter((t) => t.completed).length;
                    return (
                      <div
                        key={pb.id}
                        className="bg-slate-950/60 border border-slate-800 rounded-xl p-5 space-y-3"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-semibold text-white">{pb.title}</span>
                              <span className="text-[10px] text-slate-400 border border-slate-800 px-2 py-0.5 rounded font-mono">
                                {pb.category}
                              </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-1">{pb.triggerReason}</p>
                          </div>
                          <div className="text-right font-mono text-xs">
                            <span className="text-cyan-400 font-semibold">
                              {completedCount} / {pb.tasks.length} Done
                            </span>
                          </div>
                        </div>

                        {/* Task Checklist */}
                        <div className="divide-y divide-slate-800/80 pt-2">
                          {pb.tasks.map((task) => (
                            <div
                              key={task.id}
                              className="py-2.5 flex items-start gap-3 text-xs group"
                            >
                              <input
                                type="checkbox"
                                checked={task.completed}
                                onChange={() => togglePlaybookTask(pb.id, task.id)}
                                className="mt-0.5 rounded text-cyan-600 focus:ring-0 cursor-pointer"
                              />
                              <div className="flex-1">
                                <div
                                  className={`font-medium ${
                                    task.completed ? 'line-through text-slate-500' : 'text-slate-200'
                                  }`}
                                >
                                  {task.title}
                                </div>
                                <div className="text-slate-400 text-[11px] mt-0.5">
                                  {task.description}
                                </div>
                              </div>
                              <div className="text-right text-[11px] font-mono text-slate-400 shrink-0">
                                <div>Due: {task.dueDate}</div>
                                <div className="text-slate-500">{task.assignee}</div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: Touchpoints Timeline */}
          {activeTab === 'touchpoints' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Customer Engagement Timeline</h3>
                  <div className="text-xs text-slate-400 mt-0.5">
                    Log touchpoints, meeting notes, QBR outcomes, and support escalations
                  </div>
                </div>
                <button
                  onClick={() => setShowAddTouchpoint(!showAddTouchpoint)}
                  className="px-3 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Touchpoint</span>
                </button>
              </div>

              {/* Add Touchpoint Form */}
              {showAddTouchpoint && (
                <form
                  onSubmit={handleSaveTouchpoint}
                  className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Touchpoint Type</label>
                      <select
                        value={tpType}
                        onChange={(e) => setTpType(e.target.value as any)}
                        className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white"
                      >
                        <option value="CSM Check-in">CSM Check-in</option>
                        <option value="QBR">QBR (Executive Review)</option>
                        <option value="Executive Review">Executive Review</option>
                        <option value="Escalation Call">Escalation Call</option>
                        <option value="Training Session">Training Session</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[11px] text-slate-400 mb-1 block">Outcome Assessment</label>
                      <select
                        value={tpOutcome}
                        onChange={(e) => setTpOutcome(e.target.value as any)}
                        className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white"
                      >
                        <option value="Positive">Positive</option>
                        <option value="Neutral">Neutral</option>
                        <option value="Action Needed">Action Needed</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] text-slate-400 mb-1 block">Meeting Summary / Next Steps</label>
                    <textarea
                      value={tpSummary}
                      onChange={(e) => setTpSummary(e.target.value)}
                      rows={2}
                      required
                      placeholder="Key takeaways, customer blockers, commitments agreed upon..."
                      className="w-full text-xs bg-slate-900 border border-slate-800 rounded p-2 text-white"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setShowAddTouchpoint(false)}
                      className="px-3 py-1 text-xs text-slate-400"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-3 py-1 text-xs bg-cyan-600 text-white rounded hover:bg-cyan-500"
                    >
                      Log Entry
                    </button>
                  </div>
                </form>
              )}

              {/* Timeline feed */}
              <div className="space-y-3">
                {account.touchpoints.map((tp) => (
                  <div
                    key={tp.id}
                    className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-white">{tp.type}</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                            tp.outcome === 'Positive'
                              ? 'text-emerald-400 bg-emerald-950/60'
                              : tp.outcome === 'Action Needed'
                                ? 'text-rose-400 bg-rose-950/60'
                                : 'text-slate-400 bg-slate-900'
                          }`}
                        >
                          {tp.outcome}
                        </span>
                      </div>
                      <span className="text-slate-500 font-mono">{tp.date}</span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{tp.summary}</p>
                    <div className="text-[11px] text-slate-500 font-mono">
                      Logged by {tp.author}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: AI Customer Success Copilot */}
          {activeTab === 'copilot' && (
            <div className="space-y-5">
              {/* Copilot Action Selector Bar */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleRunDiagnostic}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                      copilotView === 'diagnostic'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                    <span>Retention & Churn Diagnostic</span>
                  </button>

                  <button
                    onClick={handleRunRenewalPitch}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                      copilotView === 'pitch'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Executive Renewal Pitch & ROI</span>
                  </button>

                  <button
                    onClick={handleRunExpansion}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                      copilotView === 'expansion'
                        ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Zap className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Expansion Case</span>
                  </button>
                </div>

                {copyFeedback && (
                  <span className="text-xs text-emerald-400 font-mono">
                    ✓ Copied to clipboard
                  </span>
                )}
              </div>

              {/* Loading State */}
              {aiLoading && (
                <div className="p-12 text-center space-y-3">
                  <div className="inline-block animate-spin w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full" />
                  <p className="text-xs text-slate-400 font-mono">
                    Synthesizing real-time telemetry and executive retention analysis...
                  </p>
                </div>
              )}

              {/* View 1: Churn Diagnostic */}
              {!aiLoading && copilotView === 'diagnostic' && (
                <div className="space-y-4">
                  {diagnosticResult ? (
                    <div className="space-y-4">
                      {/* Summary Banner */}
                      <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold font-mono uppercase tracking-wider text-slate-400">
                            Executive Diagnostic Summary
                          </span>
                          <span
                            className={`text-xs font-bold font-mono px-2 py-0.5 rounded border ${
                              diagnosticResult.churnRiskLevel === 'Critical'
                                ? 'bg-rose-950 border-rose-800 text-rose-300'
                                : diagnosticResult.churnRiskLevel === 'Elevated'
                                  ? 'bg-amber-950 border-amber-800 text-amber-300'
                                  : 'bg-emerald-950 border-emerald-800 text-emerald-300'
                            }`}
                          >
                            Risk: {diagnosticResult.churnRiskLevel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed font-sans">
                          {diagnosticResult.summary}
                        </p>
                      </div>

                      {/* Root causes */}
                      <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-2">
                        <div className="text-xs font-bold text-slate-300">
                          Identified Primary Friction Points:
                        </div>
                        <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
                          {diagnosticResult.rootCauses.map((cause, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {cause}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Immediate Actions Schedule */}
                      <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-3">
                        <div className="text-xs font-bold text-slate-300">
                          30-Day Churn Mitigation Schedule:
                        </div>
                        <div className="divide-y divide-slate-800/80">
                          {diagnosticResult.immediateActions.map((act, idx) => (
                            <div key={idx} className="py-2.5 flex flex-col sm:flex-row sm:items-start justify-between gap-2 text-xs">
                              <div>
                                <span className="font-mono text-cyan-400 font-semibold mr-2">
                                  {act.dayRange}:
                                </span>
                                <span className="text-slate-200">{act.action}</span>
                                <div className="text-[11px] text-slate-400 mt-0.5">
                                  Expected: {act.expectedOutcome}
                                </div>
                              </div>
                              <span className="text-[11px] font-mono text-slate-500 shrink-0">
                                {act.owner}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Stakeholder Strategy & Playbook */}
                      <div className="p-4 bg-cyan-950/20 border border-cyan-800/40 rounded-xl space-y-2">
                        <div className="text-xs font-bold text-cyan-300">
                          Executive Sponsor Engagement Strategy:
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed">
                          {diagnosticResult.executiveStakeholderTactics}
                        </p>
                        <div className="pt-2 flex items-center justify-between text-xs">
                          <span className="text-slate-400">
                            Recommended Playbook:{' '}
                            <strong className="text-white">
                              {diagnosticResult.recommendedPlaybook}
                            </strong>
                          </span>
                          <button
                            onClick={() => {
                              handleCopyText(
                                `${diagnosticResult.summary}\n\nActions:\n` +
                                  diagnosticResult.immediateActions
                                    .map((a) => `${a.dayRange}: ${a.action}`)
                                    .join('\n')
                              );
                            }}
                            className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Action Plan</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-8 text-center border border-slate-800 rounded-xl bg-slate-950/40 space-y-3">
                      <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto" />
                      <p className="text-xs text-slate-300">
                        Run a deep diagnostic for {account.name} to analyze retention vulnerabilities and generate an actionable 30-day recovery schedule.
                      </p>
                      <button
                        onClick={handleRunDiagnostic}
                        className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm transition-colors"
                      >
                        Generate Retention Diagnostic
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* View 2: Renewal Pitch */}
              {!aiLoading && copilotView === 'pitch' && (
                <div className="space-y-4">
                  {renewalPitchResult ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
                        <h4 className="text-sm font-bold text-white">
                          {renewalPitchResult.headline}
                        </h4>
                        <p className="text-xs text-slate-300 leading-relaxed font-sans">
                          {renewalPitchResult.quantifiedImpactSummary}
                        </p>
                      </div>

                      {/* Delivered Value highlights */}
                      <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                        <div className="text-xs font-bold text-slate-300">
                          Annual Value Delivery Proof Points:
                        </div>
                        <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
                          {renewalPitchResult.deliveredValueHighlights.map((h, i) => (
                            <li key={i} className="leading-relaxed">
                              {h}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Email Draft */}
                      <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-slate-300">
                            Ready-to-Send Executive Renewal Email
                          </span>
                          <button
                            onClick={() => handleCopyText(renewalPitchResult.emailDraftToSponsor)}
                            className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-mono"
                          >
                            <Copy className="w-3.5 h-3.5" />
                            <span>Copy Email</span>
                          </button>
                        </div>
                        <pre className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 whitespace-pre-wrap font-sans leading-relaxed">
                          {renewalPitchResult.emailDraftToSponsor}
                        </pre>
                      </div>

                      {/* Objections */}
                      <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                        <div className="text-xs font-bold text-slate-300">
                          Procurement & Budget Objection Talking Points:
                        </div>
                        <div className="space-y-2">
                          {renewalPitchResult.objectionHandling.map((obj, i) => (
                            <div key={i} className="text-xs bg-slate-900/60 p-2.5 rounded border border-slate-800">
                              <span className="font-semibold text-rose-400">
                                Objection: {obj.objection}
                              </span>
                              <p className="text-slate-300 mt-1">
                                <strong className="text-cyan-400">Counter:</strong> {obj.counter}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-8 text-center border border-slate-800 rounded-xl bg-slate-950/40 space-y-3">
                      <TrendingUp className="w-8 h-8 text-emerald-400 mx-auto" />
                      <p className="text-xs text-slate-300">
                        Generate an executive-grade ROI summary and renewal briefing email for {account.name}.
                      </p>
                      <button
                        onClick={handleRunRenewalPitch}
                        className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors"
                      >
                        Generate Renewal Pitch & ROI
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* View 3: Expansion Case */}
              {!aiLoading && copilotView === 'expansion' && (
                <div className="space-y-4">
                  {expansionResult ? (
                    <div className="space-y-4">
                      <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-cyan-400 font-mono">
                            {expansionResult.expansionAngle}
                          </span>
                          <span className="text-xs font-bold text-emerald-400 font-mono">
                            {expansionResult.projectedArrUplift}
                          </span>
                        </div>
                        <h4 className="text-sm font-semibold text-white">
                          Package: {expansionResult.recommendedPackage}
                        </h4>
                      </div>

                      <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                        <div className="text-xs font-bold text-slate-300">
                          Data-Driven Business Case:
                        </div>
                        <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
                          {expansionResult.businessCasePoints.map((pt, i) => (
                            <li key={i}>{pt}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-4 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                        <div className="text-xs font-bold text-slate-300">
                          Pitch Deck Outline (5 Slides):
                        </div>
                        <div className="space-y-1 text-xs text-slate-300 font-mono">
                          {expansionResult.executivePitchDeckOutline.map((slide, i) => (
                            <div key={i} className="p-1.5 bg-slate-900 rounded border border-slate-800/80">
                              {slide}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-8 text-center border border-slate-800 rounded-xl bg-slate-950/40 space-y-3">
                      <Zap className="w-8 h-8 text-cyan-400 mx-auto" />
                      <p className="text-xs text-slate-300">
                        Synthesize an upsell business case based on seat utilization ({account.licenses.utilizationPercent}%) and feature momentum.
                      </p>
                      <button
                        onClick={handleRunExpansion}
                        className="px-4 py-2 text-xs font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg transition-colors"
                      >
                        Build Expansion Business Case
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400 font-mono">
          <div>
            Account ID: <span className="text-slate-300">{account.id}</span> · Contract: {account.contractStartDate} to {account.renewalDate}
          </div>
          <button
            onClick={onClose}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg transition-colors font-sans"
          >
            Close 360
          </button>
        </div>
      </div>
    </div>
  );
};
