import React, { useState } from 'react';
import { useCS } from '../context/CSContext';
import { RenewalLikelihood } from '../types';
import {
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  DollarSign,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

interface RenewalWaterfallProps {
  onOpenAccount: (accountId: string) => void;
}

export const RenewalWaterfall: React.FC<RenewalWaterfallProps> = ({ onOpenAccount }) => {
  const { accounts, updateRenewalLikelihood } = useCS();

  const [selectedHorizon, setSelectedHorizon] = useState<'all' | '30' | '60' | '90' | 'q4'>('all');

  // Renewal Metrics
  const totalRenewableArr = accounts.reduce((acc, a) => acc + a.arr, 0);

  const likelyArr = accounts
    .filter((a) => a.renewalLikelihood === 'Likely' || a.renewalLikelihood === 'Won')
    .reduce((acc, a) => acc + a.arr, 0);

  const underNegotiationArr = accounts
    .filter((a) => a.renewalLikelihood === 'Under Negotiation')
    .reduce((acc, a) => acc + a.arr, 0);

  const atRiskArr = accounts
    .filter((a) => a.renewalLikelihood === 'At Risk')
    .reduce((acc, a) => acc + a.arr, 0);

  // Projected Expansion ARR identified
  const projectedExpansionArr = 288000;

  // Forecasted Retention Calculations
  // Assumes: Likely = 100%, Under Negotiation = 85%, At Risk = 40%
  const weightedRetainedArr = Math.round(
    likelyArr * 1.0 + underNegotiationArr * 0.85 + atRiskArr * 0.4
  );

  const projectedGrr = ((weightedRetainedArr / (totalRenewableArr || 1)) * 100).toFixed(1);
  const projectedNrr = (
    ((weightedRetainedArr + projectedExpansionArr) / (totalRenewableArr || 1)) *
    100
  ).toFixed(1);

  // Horizon grouping
  const filteredAccounts = accounts
    .filter((a) => {
      if (selectedHorizon === '30') return a.daysToRenewal <= 30;
      if (selectedHorizon === '60') return a.daysToRenewal <= 60;
      if (selectedHorizon === '90') return a.daysToRenewal <= 90;
      return true;
    })
    .sort((a, b) => a.daysToRenewal - b.daysToRenewal);

  return (
    <div className="space-y-6">
      {/* Title & Context */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">
            Renewal Forecasting & Net Retention (NRR)
          </h1>
          <div className="text-xs text-slate-400 mt-0.5 font-mono">
            Full Portfolio Renewal Horizon · ${(totalRenewableArr / 1_000_000).toFixed(2)}M Renewable Contract Value
          </div>
        </div>

        {/* Horizon Filter Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg text-xs">
          {[
            { id: 'all', label: 'All Horizons' },
            { id: '30', label: 'T-30 Days' },
            { id: '60', label: 'T-60 Days' },
            { id: '90', label: 'T-90 Days' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedHorizon(tab.id as any)}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                selectedHorizon === tab.id
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Retention Rate Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Net Revenue Retention (NRR)</div>
          <div className="text-2xl font-bold text-cyan-400 font-mono tabular-nums mt-1">
            {projectedNrr}%
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Benchmark: &gt;110% Top Quartile
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Gross Revenue Retention (GRR)</div>
          <div className="text-2xl font-bold text-emerald-400 font-mono tabular-nums mt-1">
            {projectedGrr}%
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Excludes expansion add-ons
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">At-Risk Renewal ARR</div>
          <div className="text-2xl font-bold text-rose-400 font-mono tabular-nums mt-1">
            ${(atRiskArr / 1_000).toFixed(0)}K
          </div>
          <div className="text-xs text-rose-400/80 mt-1 font-mono">
            {accounts.filter((a) => a.renewalLikelihood === 'At Risk').length} contracts flagged
          </div>
        </div>

        <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-4">
          <div className="text-xs text-slate-400 font-medium">Pipeline Under Negotiation</div>
          <div className="text-2xl font-bold text-amber-400 font-mono tabular-nums mt-1">
            ${(underNegotiationArr / 1_000).toFixed(0)}K
          </div>
          <div className="text-xs text-slate-400 mt-1 font-mono">
            Active procurement reviews
          </div>
        </div>
      </div>

      {/* Renewal Stage Waterfall Breakdown */}
      <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-semibold text-white">Renewal Likelihood Waterfall</h2>
          <span className="text-xs text-slate-400 font-mono">
            Total Renewable: ${(totalRenewableArr / 1000).toFixed(0)}k
          </span>
        </div>

        {/* Visual Barometer */}
        <div className="h-3 w-full rounded-full bg-slate-800 flex overflow-hidden gap-0.5">
          <div
            style={{ width: `${(likelyArr / totalRenewableArr) * 100}%` }}
            className="bg-emerald-500"
            title={`Likely: $${likelyArr}`}
          />
          <div
            style={{ width: `${(underNegotiationArr / totalRenewableArr) * 100}%` }}
            className="bg-amber-500"
            title={`Under Negotiation: $${underNegotiationArr}`}
          />
          <div
            style={{ width: `${(atRiskArr / totalRenewableArr) * 100}%` }}
            className="bg-rose-500"
            title={`At Risk: $${atRiskArr}`}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <div className="text-xs text-emerald-400 font-medium">Likely / Secured</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              ${(likelyArr / 1000).toFixed(0)}k{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((likelyArr / totalRenewableArr) * 100)}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <div className="text-xs text-amber-400 font-medium">Under Negotiation</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              ${(underNegotiationArr / 1000).toFixed(0)}k{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((underNegotiationArr / totalRenewableArr) * 100)}%)
              </span>
            </div>
          </div>

          <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-lg">
            <div className="text-xs text-rose-400 font-medium">At Risk / Intervention</div>
            <div className="text-lg font-bold text-white font-mono tabular-nums mt-1">
              ${(atRiskArr / 1000).toFixed(0)}k{' '}
              <span className="text-xs text-slate-400 font-normal">
                ({Math.round((atRiskArr / totalRenewableArr) * 100)}%)
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Renewal Contracts Roster */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 bg-slate-950/40 flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            Upcoming Renewal Schedule
          </h3>
          <span className="text-xs text-slate-500 font-mono">
            Showing {filteredAccounts.length} accounts
          </span>
        </div>

        <div className="divide-y divide-slate-800/80">
          {filteredAccounts.map((account) => {
            const isAtRisk = account.renewalLikelihood === 'At Risk';
            const isNegotiating = account.renewalLikelihood === 'Under Negotiation';

            return (
              <div
                key={account.id}
                className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-800/30 transition-colors"
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center font-bold text-slate-300 font-mono text-sm shrink-0">
                    {account.daysToRenewal}d
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenAccount(account.id)}
                        className="text-sm font-semibold text-white hover:text-cyan-400 transition-colors text-left"
                      >
                        {account.name}
                      </button>
                      <span className="text-xs text-slate-400 font-mono">
                        ${(account.arr / 1000).toFixed(0)}k ARR
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-1 font-mono">
                      <span>Contract Expiration: {account.renewalDate}</span>
                      <span aria-hidden="true">·</span>
                      <span>Health: {account.compositeHealth}/100</span>
                      <span aria-hidden="true">·</span>
                      <span>Owner: {account.csmName}</span>
                    </div>

                    {account.riskSummary && (
                      <p className="text-xs text-slate-400/90 mt-1 font-sans">
                        {account.riskSummary}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0 self-end md:self-auto">
                  <div className="flex items-center gap-1.5 text-xs font-mono">
                    <span className="text-slate-500 hidden sm:inline">Stage:</span>
                    <select
                      value={account.renewalLikelihood}
                      onChange={(e) =>
                        updateRenewalLikelihood(
                          account.id,
                          e.target.value as RenewalLikelihood
                        )
                      }
                      className="bg-slate-900 border border-slate-700 text-white rounded px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Likely">Likely</option>
                      <option value="Under Negotiation">Under Negotiation</option>
                      <option value="At Risk">At Risk</option>
                      <option value="Won">Won</option>
                      <option value="Churned">Churned</option>
                    </select>
                  </div>

                  <button
                    onClick={() => onOpenAccount(account.id)}
                    className="px-3 py-1 text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    View 360
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
