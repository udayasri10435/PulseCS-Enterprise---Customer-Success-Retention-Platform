import React from 'react';
import { useCS, NavigationTab } from '../context/CSContext';
import {
  Activity,
  Users,
  ShieldCheck,
  TrendingUp,
  Sliders,
  Plus,
  RefreshCw,
} from 'lucide-react';

interface HeaderProps {
  onOpenAddAccount: () => void;
  onOpenCopilot: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenAddAccount, onOpenCopilot }) => {
  const { activeTab, setActiveTab, resetToDefaults } = useCS();

  const navItems: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'overview', label: 'Command Center', icon: <Activity className="w-4 h-4" /> },
    { id: 'accounts', label: 'Accounts 360', icon: <Users className="w-4 h-4" /> },
    { id: 'playbooks', label: 'Playbooks Hub', icon: <ShieldCheck className="w-4 h-4" /> },
    { id: 'renewals', label: 'Renewals & NRR', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'expansion', label: 'Expansion Radar', icon: <TrendingUp className="w-4 h-4" /> },
    { id: 'health-studio', label: 'Health Studio', icon: <Sliders className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Zone 1: Single element brand wordmark */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('overview')}
              className="text-left group flex items-center gap-2.5 focus:outline-none"
            >
              <div className="w-8 h-8 rounded-lg bg-cyan-600 flex items-center justify-center font-bold text-white shadow-sm shadow-cyan-500/20 group-hover:bg-cyan-500 transition-colors">
                P
              </div>
              <span className="text-lg font-bold tracking-tight text-white group-hover:text-cyan-400 transition-colors">
                PulseCS
              </span>
            </button>
            <span className="text-xs text-slate-500 font-mono hidden sm:inline">
              / Enterprise
            </span>
          </div>

          {/* Zone 2: 4-6 text navigation links / segmented controls */}
          <nav className="hidden md:flex items-center gap-1 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            {navItems.map((item) => {
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    isActive
                      ? 'bg-slate-800 text-white shadow-sm border border-slate-700/60'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1-2 primary actions */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={onOpenCopilot}
              className="px-3 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/70 border border-cyan-800/70 rounded-lg hover:bg-cyan-900/60 hover:text-cyan-200 transition-all flex items-center gap-1.5 whitespace-nowrap"
              title="CS Intelligence & Retention Copilot"
            >
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              <span>CS Copilot</span>
            </button>

            <button
              onClick={onOpenAddAccount}
              className="px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-sm shadow-cyan-600/30 transition-all flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Account</span>
            </button>

            <button
              onClick={() => {
                if (confirm('Reset portfolio data back to default enterprise state?')) {
                  resetToDefaults();
                }
              }}
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors"
              title="Reset Demo Data"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Mobile Navigation bar for small screens */}
        <div className="flex md:hidden overflow-x-auto py-2 gap-1 border-t border-slate-800/60 no-scrollbar">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
                  isActive
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
