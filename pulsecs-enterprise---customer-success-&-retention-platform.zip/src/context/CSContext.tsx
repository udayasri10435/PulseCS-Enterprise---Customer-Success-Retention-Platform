import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Account,
  Playbook,
  ExpansionSignal,
  HealthWeights,
  RenewalLikelihood,
  HealthBreakdown,
  Touchpoint,
  Stakeholder,
} from '../types';
import {
  INITIAL_ACCOUNTS,
  INITIAL_PLAYBOOKS,
  INITIAL_EXPANSION_SIGNALS,
  INITIAL_HEALTH_WEIGHTS,
  PLAYBOOK_TEMPLATES,
} from '../data/mockData';

export type NavigationTab = 'overview' | 'accounts' | 'playbooks' | 'renewals' | 'expansion' | 'health-studio';

interface CSContextType {
  accounts: Account[];
  playbooks: Playbook[];
  expansionSignals: ExpansionSignal[];
  healthWeights: HealthWeights;
  selectedAccountId: string | null;
  activeTab: NavigationTab;
  searchQuery: string;
  healthFilter: string;
  csmFilter: string;
  horizonFilter: string;

  // Setters
  setActiveTab: (tab: NavigationTab) => void;
  setSelectedAccountId: (id: string | null) => void;
  setSearchQuery: (query: string) => void;
  setHealthFilter: (filter: string) => void;
  setCsmFilter: (filter: string) => void;
  setHorizonFilter: (filter: string) => void;

  // Domain Actions
  updateAccount: (account: Account) => void;
  updateAccountHealth: (accountId: string, partial: Partial<HealthBreakdown>) => void;
  updateRenewalLikelihood: (accountId: string, likelihood: RenewalLikelihood) => void;
  addTouchpoint: (accountId: string, touchpoint: Omit<Touchpoint, 'id'>) => void;
  addStakeholder: (accountId: string, stakeholder: Omit<Stakeholder, 'id'>) => void;
  updateAccountNotes: (accountId: string, notes: string) => void;
  togglePlaybookTask: (playbookId: string, taskId: string) => void;
  launchPlaybook: (templateId: string, accountId: string, customReason?: string) => string;
  updateExpansionSignalStatus: (signalId: string, status: ExpansionSignal['status']) => void;
  convertExpansionToPlaybook: (signalId: string) => void;
  updateHealthWeights: (weights: HealthWeights) => void;
  recalculateAllAccountsWithWeights: (weights: HealthWeights) => void;
  resetToDefaults: () => void;
  addNewAccount: (accountData: Partial<Account> & { name: string; arr: number }) => void;

  // Selected Account Helper
  selectedAccount: Account | undefined;
}

const STORAGE_KEY_ACCOUNTS = 'pulsecs_accounts_v1';
const STORAGE_KEY_PLAYBOOKS = 'pulsecs_playbooks_v1';
const STORAGE_KEY_SIGNALS = 'pulsecs_signals_v1';
const STORAGE_KEY_WEIGHTS = 'pulsecs_weights_v1';

export function calculateComposite(breakdown: HealthBreakdown, weights: HealthWeights): number {
  const sumWeights = weights.adoption + weights.sentiment + weights.support + weights.commercial;
  if (sumWeights === 0) return 0;
  const score =
    (breakdown.adoption * weights.adoption +
      breakdown.sentiment * weights.sentiment +
      breakdown.support * weights.support +
      breakdown.commercial * weights.commercial) /
    sumWeights;
  return Math.round(score);
}

const CSContext = createContext<CSContextType | undefined>(undefined);

export const CSProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [accounts, setAccounts] = useState<Account[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACCOUNTS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback to initial
    }
    return INITIAL_ACCOUNTS;
  });

  const [playbooks, setPlaybooks] = useState<Playbook[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PLAYBOOKS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback to initial
    }
    return INITIAL_PLAYBOOKS;
  });

  const [expansionSignals, setExpansionSignals] = useState<ExpansionSignal[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SIGNALS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback to initial
    }
    return INITIAL_EXPANSION_SIGNALS;
  });

  const [healthWeights, setHealthWeights] = useState<HealthWeights>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_WEIGHTS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback to initial
    }
    return INITIAL_HEALTH_WEIGHTS;
  });

  const [activeTab, setActiveTab] = useState<NavigationTab>('overview');
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [healthFilter, setHealthFilter] = useState('all');
  const [csmFilter, setCsmFilter] = useState('all');
  const [horizonFilter, setHorizonFilter] = useState('all');

  // Persistence effects
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ACCOUNTS, JSON.stringify(accounts));
    } catch {
      // ignore
    }
  }, [accounts]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PLAYBOOKS, JSON.stringify(playbooks));
    } catch {
      // ignore
    }
  }, [playbooks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SIGNALS, JSON.stringify(expansionSignals));
    } catch {
      // ignore
    }
  }, [expansionSignals]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_WEIGHTS, JSON.stringify(healthWeights));
    } catch {
      // ignore
    }
  }, [healthWeights]);

  const selectedAccount = useMemo(() => {
    return accounts.find((a) => a.id === selectedAccountId);
  }, [accounts, selectedAccountId]);

  const updateAccount = (updated: Account) => {
    setAccounts((prev) => prev.map((a) => (a.id === updated.id ? updated : a)));
  };

  const updateAccountHealth = (accountId: string, partial: Partial<HealthBreakdown>) => {
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id !== accountId) return acc;
        const newBreakdown: HealthBreakdown = {
          ...acc.healthBreakdown,
          ...partial,
        };
        const newComposite = calculateComposite(newBreakdown, healthWeights);
        const healthTrend =
          newComposite > acc.previousHealth
            ? 'improving'
            : newComposite < acc.previousHealth
              ? 'declining'
              : 'stable';

        return {
          ...acc,
          healthBreakdown: newBreakdown,
          compositeHealth: newComposite,
          healthTrend,
        };
      })
    );
  };

  const updateRenewalLikelihood = (accountId: string, likelihood: RenewalLikelihood) => {
    setAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, renewalLikelihood: likelihood } : a))
    );
  };

  const addTouchpoint = (accountId: string, touchpoint: Omit<Touchpoint, 'id'>) => {
    const newTp: Touchpoint = {
      ...touchpoint,
      id: `tp-${Date.now()}`,
    };
    setAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, touchpoints: [newTp, ...a.touchpoints] } : a))
    );
  };

  const addStakeholder = (accountId: string, stakeholder: Omit<Stakeholder, 'id'>) => {
    const newStk: Stakeholder = {
      ...stakeholder,
      id: `stk-${Date.now()}`,
    };
    setAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, stakeholders: [...a.stakeholders, newStk] } : a))
    );
  };

  const updateAccountNotes = (accountId: string, notes: string) => {
    setAccounts((prev) =>
      prev.map((a) => (a.id === accountId ? { ...a, notes } : a))
    );
  };

  const togglePlaybookTask = (playbookId: string, taskId: string) => {
    setPlaybooks((prev) =>
      prev.map((pb) => {
        if (pb.id !== playbookId) return pb;
        const updatedTasks = pb.tasks.map((t) =>
          t.id === taskId ? { ...t, completed: !t.completed } : t
        );
        const allCompleted = updatedTasks.every((t) => t.completed);
        return {
          ...pb,
          tasks: updatedTasks,
          status: allCompleted ? 'completed' : 'active',
          completedAt: allCompleted ? new Date().toISOString().split('T')[0] : undefined,
        };
      })
    );
  };

  const launchPlaybook = (templateId: string, accountId: string, customReason?: string): string => {
    const tpl = PLAYBOOK_TEMPLATES.find((t) => t.id === templateId) || PLAYBOOK_TEMPLATES[0];
    const acc = accounts.find((a) => a.id === accountId);
    if (!acc) return '';

    const newPbId = `pb-${Date.now()}`;
    const today = new Date();

    const tasks = tpl.defaultTasks.map((t, idx) => {
      const dueDate = new Date(today);
      dueDate.setDate(today.getDate() + t.daysOffset);
      return {
        id: `tsk-${newPbId}-${idx}`,
        title: t.title,
        description: t.description,
        assignee: acc.csmName,
        dueDate: dueDate.toISOString().split('T')[0],
        completed: false,
        stage: t.stage,
      };
    });

    const newPlaybook: Playbook = {
      id: newPbId,
      templateId: tpl.id,
      title: tpl.name,
      category: tpl.category,
      targetAccountId: acc.id,
      targetAccountName: acc.name,
      status: 'active',
      startedAt: today.toISOString().split('T')[0],
      tasks,
      arrAtStake: acc.arr,
      triggerReason: customReason || tpl.triggerDescription,
    };

    setPlaybooks((prev) => [newPlaybook, ...prev]);

    // Link playbook to account
    setAccounts((prev) =>
      prev.map((a) =>
        a.id === accountId
          ? { ...a, activePlaybookIds: [newPbId, ...a.activePlaybookIds] }
          : a
      )
    );

    return newPbId;
  };

  const updateExpansionSignalStatus = (signalId: string, status: ExpansionSignal['status']) => {
    setExpansionSignals((prev) =>
      prev.map((s) => (s.id === signalId ? { ...s, status } : s))
    );
  };

  const convertExpansionToPlaybook = (signalId: string) => {
    const signal = expansionSignals.find((s) => s.id === signalId);
    if (!signal) return;

    launchPlaybook(
      'tpl-seat-expansion-fasttrack',
      signal.accountId,
      `Triggered by Expansion Signal: ${signal.type} - ${signal.detail}`
    );
    updateExpansionSignalStatus(signalId, 'In Progress');
  };

  const updateHealthWeights = (weights: HealthWeights) => {
    setHealthWeights(weights);
  };

  const recalculateAllAccountsWithWeights = (weights: HealthWeights) => {
    setHealthWeights(weights);
    setAccounts((prev) =>
      prev.map((acc) => {
        const newScore = calculateComposite(acc.healthBreakdown, weights);
        const healthTrend =
          newScore > acc.previousHealth
            ? 'improving'
            : newScore < acc.previousHealth
              ? 'declining'
              : 'stable';
        return {
          ...acc,
          compositeHealth: newScore,
          healthTrend,
        };
      })
    );
  };

  const addNewAccount = (data: Partial<Account> & { name: string; arr: number }) => {
    const newId = `acc-${Date.now()}`;
    const initialBreakdown: HealthBreakdown = {
      adoption: 75,
      sentiment: 75,
      support: 80,
      commercial: 80,
    };
    const comp = calculateComposite(initialBreakdown, healthWeights);

    const fullAccount: Account = {
      id: newId,
      name: data.name,
      domain: data.domain || `${data.name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
      industry: data.industry || 'Technology',
      tier: data.tier || 'Enterprise',
      arr: data.arr,
      csmName: data.csmName || 'Marcus Vance',
      csmEmail: 'marcus.vance@pulsecs.internal',
      renewalDate: data.renewalDate || '2027-04-30',
      contractStartDate: '2026-04-30',
      daysToRenewal: 180,
      renewalLikelihood: 'Likely',
      compositeHealth: comp,
      previousHealth: comp,
      healthTrend: 'stable',
      healthBreakdown: initialBreakdown,
      licenses: {
        totalSeats: 200,
        activeSeats: 160,
        utilizationPercent: 80,
        dauToMauRatio: 0.65,
        monthlyActiveUsers: 155,
        topFeaturesUsed: ['Core Workspaces', 'Dashboard Exports'],
        underutilizedFeatures: ['Advanced Automations'],
      },
      activePlaybookIds: [],
      expansionSignalIds: [],
      stakeholders: [
        {
          id: `stk-${Date.now()}`,
          name: 'Lead Stakeholder',
          role: 'VP Technology',
          email: `lead@${data.name.toLowerCase().replace(/[^a-z0-9]/g, '')}.com`,
          sentiment: 'Positive',
          lastEngaged: '2026-09-20',
          isExecSponsor: true,
        },
      ],
      touchpoints: [
        {
          id: `tp-${Date.now()}`,
          date: '2026-09-20',
          type: 'CSM Check-in',
          summary: 'Account onboarded and initial kickoff completed.',
          author: 'Marcus Vance',
          outcome: 'Positive',
        },
      ],
      tags: ['New Account'],
      riskSummary: 'Initial onboarding phase. Monitoring adoption.',
      notes: 'Kickoff successful.',
    };

    setAccounts((prev) => [fullAccount, ...prev]);
  };

  const resetToDefaults = () => {
    localStorage.removeItem(STORAGE_KEY_ACCOUNTS);
    localStorage.removeItem(STORAGE_KEY_PLAYBOOKS);
    localStorage.removeItem(STORAGE_KEY_SIGNALS);
    localStorage.removeItem(STORAGE_KEY_WEIGHTS);
    setAccounts(INITIAL_ACCOUNTS);
    setPlaybooks(INITIAL_PLAYBOOKS);
    setExpansionSignals(INITIAL_EXPANSION_SIGNALS);
    setHealthWeights(INITIAL_HEALTH_WEIGHTS);
  };

  return (
    <CSContext.Provider
      value={{
        accounts,
        playbooks,
        expansionSignals,
        healthWeights,
        selectedAccountId,
        activeTab,
        searchQuery,
        healthFilter,
        csmFilter,
        horizonFilter,
        setActiveTab,
        setSelectedAccountId,
        setSearchQuery,
        setHealthFilter,
        setCsmFilter,
        setHorizonFilter,
        updateAccount,
        updateAccountHealth,
        updateRenewalLikelihood,
        addTouchpoint,
        addStakeholder,
        updateAccountNotes,
        togglePlaybookTask,
        launchPlaybook,
        updateExpansionSignalStatus,
        convertExpansionToPlaybook,
        updateHealthWeights,
        recalculateAllAccountsWithWeights,
        resetToDefaults,
        addNewAccount,
        selectedAccount,
      }}
    >
      {children}
    </CSContext.Provider>
  );
};

export const useCS = (): CSContextType => {
  const context = useContext(CSContext);
  if (!context) {
    throw new Error('useCS must be used within a CSProvider');
  }
  return context;
};
