export type HealthTier = 'champion' | 'healthy' | 'at_risk' | 'critical';
export type RenewalLikelihood = 'Likely' | 'Under Negotiation' | 'At Risk' | 'Won' | 'Churned';
export type CustomerTier = 'Strategic' | 'Enterprise' | 'Mid-Market' | 'Growth';

export interface HealthBreakdown {
  adoption: number; // 0-100 (feature breadth, DAU/MAU, seat fill)
  sentiment: number; // 0-100 (CSAT, stakeholder meetings, exec sponsor)
  support: number; // 0-100 (open tickets, SLA health, escalation frequency)
  commercial: number; // 0-100 (contract tenure, invoice promptness, budget stability)
}

export interface LicenseUsage {
  totalSeats: number;
  activeSeats: number;
  utilizationPercent: number;
  dauToMauRatio: number; // e.g. 0.68 (68%)
  monthlyActiveUsers: number;
  topFeaturesUsed: string[];
  underutilizedFeatures: string[];
}

export interface Stakeholder {
  id: string;
  name: string;
  role: string;
  email: string;
  sentiment: 'Champion' | 'Positive' | 'Neutral' | 'Detractor';
  lastEngaged: string;
  isExecSponsor: boolean;
}

export interface Touchpoint {
  id: string;
  date: string;
  type: 'Executive Review' | 'QBR' | 'CSM Check-in' | 'Escalation Call' | 'Training Session';
  summary: string;
  author: string;
  outcome: 'Positive' | 'Neutral' | 'Action Needed';
}

export interface ExpansionSignal {
  id: string;
  accountId: string;
  accountName: string;
  type: 'Seat Saturation (>90%)' | 'Feature Gate Click' | 'Cross-Department Rollout' | 'High NPS Promoter' | 'API Volume Spike';
  detail: string;
  potentialArr: number;
  detectedDate: string;
  urgency: 'Immediate' | 'High' | 'Moderate';
  recommendedAction: string;
  status: 'New' | 'In Progress' | 'Converted' | 'Dismissed';
}

export interface Account {
  id: string;
  name: string;
  domain: string;
  industry: string;
  tier: CustomerTier;
  arr: number; // annual recurring revenue in USD
  csmName: string;
  csmAvatar?: string;
  csmEmail: string;
  renewalDate: string;
  contractStartDate: string;
  daysToRenewal: number;
  renewalLikelihood: RenewalLikelihood;
  compositeHealth: number; // 0-100
  previousHealth: number; // 30 days ago
  healthTrend: 'improving' | 'declining' | 'stable';
  healthBreakdown: HealthBreakdown;
  licenses: LicenseUsage;
  activePlaybookIds: string[];
  expansionSignalIds: string[];
  stakeholders: Stakeholder[];
  touchpoints: Touchpoint[];
  tags: string[];
  riskSummary?: string;
  notes: string;
}

export interface PlaybookTask {
  id: string;
  title: string;
  description: string;
  assignee: string;
  dueDate: string;
  completed: boolean;
  stage: 'Discovery' | 'Executive Alignment' | 'Technical Resolution' | 'Commercial & Close';
}

export type PlaybookCategory = 'Churn Prevention' | 'Renewal Acceleration' | 'Expansion Play' | 'Executive Alignment' | 'Onboarding Recovery';

export interface Playbook {
  id: string;
  templateId: string;
  title: string;
  category: PlaybookCategory;
  targetAccountId: string;
  targetAccountName: string;
  status: 'active' | 'completed' | 'on_hold';
  startedAt: string;
  completedAt?: string;
  tasks: PlaybookTask[];
  arrAtStake: number;
  triggerReason: string;
}

export interface PlaybookTemplate {
  id: string;
  name: string;
  category: Playbook['category'];
  description: string;
  triggerDescription: string;
  defaultTasks: {
    title: string;
    description: string;
    stage: PlaybookTask['stage'];
    daysOffset: number;
  }[];
}

export interface HealthWeights {
  adoption: number; // percentage (e.g. 35)
  sentiment: number; // percentage (e.g. 25)
  support: number; // percentage (e.g. 20)
  commercial: number; // percentage (e.g. 20)
}

export interface RenewalForecastSummary {
  quarter: string;
  renewableArr: number;
  forecastedRetainedArr: number;
  forecastedExpansionArr: number;
  forecastedChurnArr: number;
  projectedNrr: number; // e.g. 114.2%
  projectedGrr: number; // e.g. 93.5%
  accountsCount: number;
}
