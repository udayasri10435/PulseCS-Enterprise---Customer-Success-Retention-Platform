import React, { useState } from 'react';
import { CSProvider, useCS } from './context/CSContext';
import { Header } from './components/Header';
import { ExecutiveOverview } from './components/ExecutiveOverview';
import { AccountsList } from './components/AccountsList';
import { PlaybooksHub } from './components/PlaybooksHub';
import { RenewalWaterfall } from './components/RenewalWaterfall';
import { ExpansionRadar } from './components/ExpansionRadar';
import { HealthStudio } from './components/HealthStudio';
import { AccountDetailModal } from './components/AccountDetailModal';
import { AddAccountModal } from './components/AddAccountModal';
import { AICopilotModal } from './components/AICopilotModal';

function MainApp() {
  const { activeTab, setActiveTab, selectedAccount, setSelectedAccountId } = useCS();

  const [isAddAccountOpen, setIsAddAccountOpen] = useState(false);
  const [isCopilotOpen, setIsCopilotOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/20 selection:text-cyan-200">
      {/* Top Header Contract */}
      <Header
        onOpenAddAccount={() => setIsAddAccountOpen(true)}
        onOpenCopilot={() => setIsCopilotOpen(true)}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'overview' && (
          <ExecutiveOverview
            onOpenAccount={(id) => setSelectedAccountId(id)}
            onOpenPlaybook={() => setActiveTab('playbooks')}
          />
        )}

        {activeTab === 'accounts' && (
          <AccountsList
            onOpenAccount={(id) => setSelectedAccountId(id)}
            onOpenAddAccount={() => setIsAddAccountOpen(true)}
          />
        )}

        {activeTab === 'playbooks' && (
          <PlaybooksHub onOpenAccount={(id) => setSelectedAccountId(id)} />
        )}

        {activeTab === 'renewals' && (
          <RenewalWaterfall onOpenAccount={(id) => setSelectedAccountId(id)} />
        )}

        {activeTab === 'expansion' && (
          <ExpansionRadar onOpenAccount={(id) => setSelectedAccountId(id)} />
        )}

        {activeTab === 'health-studio' && (
          <HealthStudio onOpenAccount={(id) => setSelectedAccountId(id)} />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950/80 py-4 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>PulseCS Enterprise Customer Success Platform · Proactive Retention Architecture</span>
          <div className="flex items-center gap-3 text-slate-400">
            <span>Gainsight / Totango Competitor Benchmark</span>
            <span aria-hidden="true">·</span>
            <span className="text-cyan-400">Live Health Engine Active</span>
          </div>
        </div>
      </footer>

      {/* Account 360 Workspace Modal */}
      {selectedAccount && (
        <AccountDetailModal
          account={selectedAccount}
          onClose={() => setSelectedAccountId(null)}
        />
      )}

      {/* Add Account Modal */}
      <AddAccountModal
        isOpen={isAddAccountOpen}
        onClose={() => setIsAddAccountOpen(false)}
        onSuccess={(id) => setSelectedAccountId(id)}
      />

      {/* AI CS Copilot Modal */}
      <AICopilotModal
        isOpen={isCopilotOpen}
        onClose={() => setIsCopilotOpen(false)}
        onOpenAccount={(id) => {
          setIsCopilotOpen(false);
          setSelectedAccountId(id);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <CSProvider>
      <MainApp />
    </CSProvider>
  );
}
